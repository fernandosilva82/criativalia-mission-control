const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const axios = require('axios');

const app = express();
const PORT = 7778;

// Evolution API config
const EVOLUTION_URL = process.env.EVOLUTION_URL || 'http://agency-evolution:8080';
const EVOLUTION_KEY = process.env.EVOLUTION_API_KEY || 'agency-evolution-2024';

app.use(cors());
app.use(express.json());

// Database
const DB_PATH = '/opt/agency/database/agency.db';
const db = new sqlite3.Database(DB_PATH);

// Init database
function initDB() {
  db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS campaigns (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      status TEXT DEFAULT 'draft',
      template_id INTEGER,
      mailing_id INTEGER,
      instance_name TEXT,
      total_recipients INTEGER DEFAULT 0,
      sent_count INTEGER DEFAULT 0,
      delivered_count INTEGER DEFAULT 0,
      read_count INTEGER DEFAULT 0,
      replied_count INTEGER DEFAULT 0,
      failed_count INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS templates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      content TEXT NOT NULL,
      variables TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS mailing_lists (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      total_contacts INTEGER DEFAULT 0,
      valid_contacts INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS contacts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      mailing_id INTEGER,
      phone TEXT NOT NULL,
      name TEXT,
      status TEXT DEFAULT 'pending',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Tabela de warm-up de chips
    db.run(`CREATE TABLE IF NOT EXISTS warmup_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      instance_name TEXT NOT NULL,
      status TEXT DEFAULT 'running',
      stage TEXT DEFAULT 'initial',
      progress INTEGER DEFAULT 0,
      target_score INTEGER DEFAULT 100,
      current_score INTEGER DEFAULT 0,
      messages_sent INTEGER DEFAULT 0,
      messages_received INTEGER DEFAULT 0,
      started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      completed_at DATETIME,
      config TEXT
    )`);

    // Tabela de logs de warm-up
    db.run(`CREATE TABLE IF NOT EXISTS warmup_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id INTEGER,
      action TEXT,
      details TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Tabela de números buddies para warm-up
    db.run(`CREATE TABLE IF NOT EXISTS warmup_buddies (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      phone TEXT NOT NULL UNIQUE,
      active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);
  });
}

// ========== EVOLUTION API INTEGRATION ==========

// Listar instâncias
app.get('/api/evolution/instances', async (req, res) => {
  try {
    const response = await axios.get(`${EVOLUTION_URL}/instance/fetchInstances`, {
      headers: { 'apikey': EVOLUTION_KEY }
    });
    res.json(response.data);
  } catch (error) {
    console.error('Evolution error:', error.message);
    res.json({ instances: [] });
  }
});

// Verificar se número existe no WhatsApp
app.post('/api/evolution/instances/:name/check-number', async (req, res) => {
  const { number } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/whatsappNumbers/${req.params.name}`,
      { numbers: [number] },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Check number error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Verificar múltiplos números (bulk)
app.post('/api/evolution/instances/:name/check-numbers', async (req, res) => {
  const { numbers } = req.body; // array de números
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/whatsappNumbers/${req.params.name}`,
      { numbers },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Check numbers error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Obter informações do perfil de um número
app.post('/api/evolution/instances/:name/profile', async (req, res) => {
  const { number } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/fetchProfile/${req.params.name}`,
      { number },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Profile error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Obter foto de perfil
app.post('/api/evolution/instances/:name/profile-picture', async (req, res) => {
  const { number } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/getBase64FromMediaMessage/${req.params.name}`,
      { number, messageId: 'profile' },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Obter status/stories de um número
app.post('/api/evolution/instances/:name/status', async (req, res) => {
  const { number } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/getStatus/${req.params.name}`,
      { number },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Listar todos os contatos da instância
app.get('/api/evolution/instances/:name/contacts', async (req, res) => {
  try {
    const response = await axios.get(
      `${EVOLUTION_URL}/chat/findContacts/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Contacts error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Listar chats/conversas
app.get('/api/evolution/instances/:name/chats', async (req, res) => {
  try {
    const response = await axios.get(
      `${EVOLUTION_URL}/chat/findChats/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Chats error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Obter mensagens de um chat
app.post('/api/evolution/instances/:name/messages', async (req, res) => {
  const { number, limit = 50 } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/findMessages/${req.params.name}`,
      { number, limit },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Enviar mensagem de texto
app.post('/api/evolution/instances/:name/send-text', async (req, res) => {
  const { number, text } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/message/sendText/${req.params.name}`,
      { number, text },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Send text error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Enviar imagem
app.post('/api/evolution/instances/:name/send-image', async (req, res) => {
  const { number, image, caption } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/message/sendMedia/${req.params.name}`,
      { number, media: image, caption, mediaType: 'image' },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Enviar documento/PDF
app.post('/api/evolution/instances/:name/send-document', async (req, res) => {
  const { number, document, caption, fileName } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/message/sendMedia/${req.params.name}`,
      { number, media: document, caption, fileName, mediaType: 'document' },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Enviar áudio
app.post('/api/evolution/instances/:name/send-audio', async (req, res) => {
  const { number, audio } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/message/sendWhatsAppAudio/${req.params.name}`,
      { number, audio },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Enviar localização
app.post('/api/evolution/instances/:name/send-location', async (req, res) => {
  const { number, latitude, longitude, title, address } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/message/sendLocation/${req.params.name}`,
      { number, latitude, longitude, title, address },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Enviar botões interativos
app.post('/api/evolution/instances/:name/send-buttons', async (req, res) => {
  const { number, title, description, footer, buttons } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/message/sendButtons/${req.params.name}`,
      { number, title, description, footer, buttons },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Enviar lista de opções
app.post('/api/evolution/instances/:name/send-list', async (req, res) => {
  const { number, title, description, buttonText, sections } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/message/sendList/${req.params.name}`,
      { number, title, description, buttonText, sections },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Presença (typing...)
app.post('/api/evolution/instances/:name/presence', async (req, res) => {
  const { number, presence } = req.body; // presence: 'composing', 'paused', 'available'
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/sendPresence/${req.params.name}`,
      { number, presence },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Arquivar chat
app.post('/api/evolution/instances/:name/archive', async (req, res) => {
  const { number, archive = true } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/archiveChat/${req.params.name}`,
      { number, archive },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Fixar chat
app.post('/api/evolution/instances/:name/pin', async (req, res) => {
  const { number, pin = true } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/pinChat/${req.params.name}`,
      { number, pin },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Marcar como não lido
app.post('/api/evolution/instances/:name/mark-unread', async (req, res) => {
  const { number } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/markChatUnread/${req.params.name}`,
      { number },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Bloquear contato
app.post('/api/evolution/instances/:name/block', async (req, res) => {
  const { number, block = true } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/blockUser/${req.params.name}`,
      { number, status: block ? 'block' : 'unblock' },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Obter informações do grupo
app.post('/api/evolution/instances/:name/group-info', async (req, res) => {
  const { groupId } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/findGroupInfos/${req.params.name}`,
      { groupJid: groupId },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Listar participantes do grupo
app.post('/api/evolution/instances/:name/group-participants', async (req, res) => {
  const { groupId } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/findParticipants/${req.params.name}`,
      { groupJid: groupId },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Atualizar nome do grupo
app.post('/api/evolution/instances/:name/group-update-name', async (req, res) => {
  const { groupId, subject } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/updateGroupName/${req.params.name}`,
      { groupJid: groupId, subject },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Atualizar descrição do grupo
app.post('/api/evolution/instances/:name/group-update-description', async (req, res) => {
  const { groupId, description } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/updateGroupDescription/${req.params.name}`,
      { groupJid: groupId, description },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Atualizar foto do grupo
app.post('/api/evolution/instances/:name/group-update-picture', async (req, res) => {
  const { groupId, image } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/updateGroupPicture/${req.params.name}`,
      { groupJid: groupId, image },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Sair do grupo
app.post('/api/evolution/instances/:name/group-leave', async (req, res) => {
  const { groupId } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/leaveGroup/${req.params.name}`,
      { groupJid: groupId },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Criar grupo
app.post('/api/evolution/instances/:name/group-create', async (req, res) => {
  const { subject, description, participants } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/create/${req.params.name}`,
      { subject, description, participants },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Adicionar participantes ao grupo
app.post('/api/evolution/instances/:name/group-add-participants', async (req, res) => {
  const { groupId, participants } = req.body; // participants: array de números
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/updateParticipant/${req.params.name}`,
      { groupJid: groupId, action: 'add', participants },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Remover participantes do grupo
app.post('/api/evolution/instances/:name/group-remove-participants', async (req, res) => {
  const { groupId, participants } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/updateParticipant/${req.params.name}`,
      { groupJid: groupId, action: 'remove', participants },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Promover a admin
app.post('/api/evolution/instances/:name/group-promote', async (req, res) => {
  const { groupId, participants } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/updateParticipant/${req.params.name}`,
      { groupJid: groupId, action: 'promote', participants },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Rebaixar admin
app.post('/api/evolution/instances/:name/group-demote', async (req, res) => {
  const { groupId, participants } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/updateParticipant/${req.params.name}`,
      { groupJid: groupId, action: 'demote', participants },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Gerar link de convite do grupo
app.post('/api/evolution/instances/:name/group-invite-link', async (req, res) => {
  const { groupId, reset = false } = req.body;
  try {
    const url = reset 
      ? `${EVOLUTION_URL}/group/revokeInviteCode/${req.params.name}`
      : `${EVOLUTION_URL}/group/inviteCode/${req.params.name}`;
    const response = await axios.post(
      url,
      { groupJid: groupId },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Configurações do grupo
app.post('/api/evolution/instances/:name/group-settings', async (req, res) => {
  const { groupId, setting, value } = req.body; // setting: 'announcement', 'restrict', etc
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/toggleEphemeral/${req.params.name}`,
      { groupJid: groupId, expiration: value },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Criar instância
app.post('/api/evolution/instances', async (req, res) => {
  const { name, description } = req.body;
  try {
    const response = await axios.post(`${EVOLUTION_URL}/instance/create`, {
      instanceName: name,
      description: description || '',
      qrcode: true,
      number: ''
    }, {
      headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' }
    });
    res.json(response.data);
  } catch (error) {
    console.error('Create instance error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Conectar (QR Code)
app.get('/api/evolution/instances/:name/connect', async (req, res) => {
  try {
    const response = await axios.get(
      `${EVOLUTION_URL}/instance/connect/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Connect error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Status
app.get('/api/evolution/instances/:name/status', async (req, res) => {
  try {
    const response = await axios.get(
      `${EVOLUTION_URL}/instance/connectionState/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Logout
app.post('/api/evolution/instances/:name/logout', async (req, res) => {
  try {
    const response = await axios.delete(
      `${EVOLUTION_URL}/instance/logout/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Deletar
app.delete('/api/evolution/instances/:name', async (req, res) => {
  try {
    const response = await axios.delete(
      `${EVOLUTION_URL}/instance/delete/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Enviar mensagem
app.post('/api/evolution/instances/:name/send', async (req, res) => {
  const { number, message } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/message/sendText/${req.params.name}`,
      { number, text: message },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Criar instância
app.post('/api/evolution/instances', async (req, res) => {
  const { name, description } = req.body;
  try {
    const response = await axios.post(`${EVOLUTION_URL}/instance/create`, {
      instanceName: name,
      description: description || '',
      qrcode: true,
      number: ''
    }, {
      headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' }
    });
    res.json(response.data);
  } catch (error) {
    console.error('Create instance error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Conectar (QR Code)
app.get('/api/evolution/instances/:name/connect', async (req, res) => {
  try {
    const response = await axios.get(
      `${EVOLUTION_URL}/instance/connect/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Connect error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Status da conexão
app.get('/api/evolution/instances/:name/connection', async (req, res) => {
  try {
    const response = await axios.get(
      `${EVOLUTION_URL}/instance/connectionState/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Logout
app.post('/api/evolution/instances/:name/logout', async (req, res) => {
  try {
    const response = await axios.delete(
      `${EVOLUTION_URL}/instance/logout/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Deletar instância
app.delete('/api/evolution/instances/:name', async (req, res) => {
  try {
    const response = await axios.delete(
      `${EVOLUTION_URL}/instance/delete/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ========== TEMPLATES ==========

app.get('/api/templates', (req, res) => {
  db.all("SELECT * FROM templates ORDER BY created_at DESC", (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/templates', (req, res) => {
  const { name, content, variables } = req.body;
  db.run(
    "INSERT INTO templates (name, content, variables) VALUES (?, ?, ?)",
    [name, content, JSON.stringify(variables || [])],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID, message: 'Template criado' });
    }
  );
});

app.delete('/api/templates/:id', (req, res) => {
  db.run("DELETE FROM templates WHERE id = ?", [req.params.id], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: 'Template deletado' });
  });
});

// ========== MAILING ==========

app.get('/api/mailing', (req, res) => {
  db.all("SELECT * FROM mailing_lists ORDER BY created_at DESC", (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/mailing', (req, res) => {
  const { name } = req.body;
  db.run("INSERT INTO mailing_lists (name) VALUES (?)", [name], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ id: this.lastID, message: 'Lista criada' });
  });
});

app.get('/api/mailing/:id/contacts', (req, res) => {
  db.all("SELECT * FROM contacts WHERE mailing_id = ?", [req.params.id], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/mailing/:id/contacts', (req, res) => {
  const { contacts } = req.body;
  const stmt = db.prepare("INSERT INTO contacts (mailing_id, phone, name) VALUES (?, ?, ?)");
  let count = 0;
  
  contacts.forEach(c => {
    stmt.run(req.params.id, c.phone, c.name);
    count++;
  });
  stmt.finalize();
  
  db.run(
    "UPDATE mailing_lists SET total_contacts = (SELECT COUNT(*) FROM contacts WHERE mailing_id = ?) WHERE id = ?",
    [req.params.id, req.params.id]
  );
  
  res.json({ imported: count });
});

app.delete('/api/mailing/:id', (req, res) => {
  db.run("DELETE FROM contacts WHERE mailing_id = ?", [req.params.id], () => {
    db.run("DELETE FROM mailing_lists WHERE id = ?", [req.params.id], function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Lista deletada' });
    });
  });
});

// ========== CAMPANHAS ==========

app.get('/api/campaigns', (req, res) => {
  db.all(`
    SELECT c.*, t.name as template_name, m.name as mailing_name
    FROM campaigns c
    LEFT JOIN templates t ON c.template_id = t.id
    LEFT JOIN mailing_lists m ON c.mailing_id = m.id
    ORDER BY c.created_at DESC
  `, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/campaigns', (req, res) => {
  const { name, template_id, mailing_id, instance_name } = req.body;
  
  db.get("SELECT COUNT(*) as count FROM contacts WHERE mailing_id = ?", [mailing_id], (err, row) => {
    const total = row.count;
    
    db.run(
      "INSERT INTO campaigns (name, template_id, mailing_id, instance_name, total_recipients) VALUES (?, ?, ?, ?, ?)",
      [name, template_id, mailing_id, instance_name, total],
      function(err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ id: this.lastID, message: 'Campanha criada', total_recipients: total });
      }
    );
  });
});

// Iniciar campanha
app.post('/api/campaigns/:id/start', async (req, res) => {
  const campaignId = req.params.id;
  
  db.get(`
    SELECT c.*, t.content as template_content
    FROM campaigns c
    LEFT JOIN templates t ON c.template_id = t.id
    WHERE c.id = ?
  `, [campaignId], async (err, campaign) => {
    if (err || !campaign) {
      return res.status(404).json({ error: 'Campanha não encontrada' });
    }
    
    db.all("SELECT * FROM contacts WHERE mailing_id = ?", [campaign.mailing_id], async (err, contacts) => {
      if (contacts.length === 0) {
        return res.status(400).json({ error: 'Nenhum contato' });
      }
      
      db.run("UPDATE campaigns SET status = 'running' WHERE id = ?", [campaignId]);
      
      res.json({ message: 'Campanha iniciada', total: contacts.length });
      
      // Enviar em background
      sendMessages(campaign, contacts);
    });
  });
});

async function sendMessages(campaign, contacts) {
  let sent = 0;
  let failed = 0;
  
  for (const contact of contacts) {
    try {
      let message = campaign.template_content;
      message = message.replace(/{{nome}}/g, contact.name || '');
      message = message.replace(/{{telefone}}/g, contact.phone);
      
      await axios.post(
        `${EVOLUTION_URL}/message/sendText/${campaign.instance_name}`,
        { number: contact.phone, text: message },
        { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
      );
      
      sent++;
      db.run("UPDATE campaigns SET sent_count = ? WHERE id = ?", [sent, campaign.id]);
      
      await new Promise(r => setTimeout(r, 5000 + Math.random() * 5000));
    } catch (error) {
      failed++;
      console.error('Erro:', error.message);
    }
  }
  
  db.run("UPDATE campaigns SET status = 'completed', sent_count = ?, failed_count = ? WHERE id = ?",
    [sent, failed, campaign.id]);
}

app.delete('/api/campaigns/:id', (req, res) => {
  db.run("DELETE FROM campaigns WHERE id = ?", [req.params.id], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: 'Campanha deletada' });
  });
});

// ========== UPLOAD CSV PARA MAILING ==========

app.post('/api/mailing/:id/upload-csv', express.json({ limit: '10mb' }), (req, res) => {
  const mailingId = req.params.id;
  const { csvData } = req.body;
  
  if (!csvData) {
    return res.status(400).json({ error: 'Dados CSV não fornecidos' });
  }
  
  const lines = csvData.trim().split('\n');
  const contacts = [];
  let format = 'unknown';
  
  // Detectar formato
  const firstLine = lines[0].toLowerCase();
  if (firstLine.includes('nome') && firstLine.includes('telefone')) {
    format = 'nome-telefone';
  } else if (firstLine.includes('name') && firstLine.includes('phone')) {
    format = 'name-phone';
  } else if (firstLine.includes('telefone') || firstLine.includes('phone') || firstLine.includes('numero')) {
    format = 'telefone-only';
  } else if (lines[0].includes(',')) {
    format = 'csv-raw';
  }
  
  // Parse CSV
  const startIndex = (format === 'nome-telefone' || format === 'name-phone' || format === 'telefone-only') ? 1 : 0;
  
  for (let i = startIndex; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    const parts = line.split(',').map(p => p.trim());
    
    if (format === 'nome-telefone' || format === 'name-phone') {
      const name = parts[0];
      const phone = parts[1]?.replace(/\D/g, '');
      if (phone && phone.length >= 10) {
        contacts.push({ name, phone });
      }
    } else if (format === 'telefone-only') {
      const phone = parts[0]?.replace(/\D/g, '');
      if (phone && phone.length >= 10) {
        contacts.push({ name: '', phone });
      }
    } else {
      // csv-raw: tentar detectar
      const phone = parts.find(p => p.replace(/\D/g, '').length >= 10)?.replace(/\D/g, '');
      const name = parts.find(p => p.replace(/\D/g, '').length < 10 && p.length > 2) || '';
      if (phone) {
        contacts.push({ name, phone });
      }
    }
  }
  
  // Inserir no banco
  let inserted = 0;
  const stmt = db.prepare("INSERT INTO contacts (mailing_id, phone, name) VALUES (?, ?, ?)");
  
  contacts.forEach(contact => {
    stmt.run(mailingId, contact.phone, contact.name);
    inserted++;
  });
  
  stmt.finalize();
  
  // Atualizar contagem
  db.run(
    "UPDATE mailing_lists SET total_contacts = total_contacts + ? WHERE id = ?",
    [inserted, mailingId]
  );
  
  res.json({
    message: `${inserted} contatos importados`,
    total: inserted,
    format: format,
    sample: contacts.slice(0, 3)
  });
});

// ========== WARM-UP DE CHIP ==========

// Iniciar sessão de warm-up
app.post('/api/warmup/start', (req, res) => {
  const { instance_name, config } = req.body;
  
  if (!instance_name) {
    return res.status(400).json({ error: 'Nome da instância obrigatório' });
  }
  
  const defaultConfig = {
    messagesPerDay: 50,
    minDelay: 30000,  // 30s
    maxDelay: 120000, // 2min
    stages: ['initial', 'building', 'active', 'mature'],
    currentStage: 'initial'
  };
  
  const finalConfig = JSON.stringify({ ...defaultConfig, ...config });
  
  db.run(
    `INSERT INTO warmup_sessions (instance_name, status, stage, progress, config)
     VALUES (?, 'running', 'initial', 0, ?)`,
    [instance_name, finalConfig],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      
      const sessionId = this.lastID;
      
      // Iniciar processo de warm-up em background
      startWarmup(sessionId, instance_name, { ...defaultConfig, ...config });
      
      res.json({
        id: sessionId,
        message: 'Warm-up iniciado',
        instance: instance_name,
        status: 'running'
      });
    }
  );
});

// Listar sessões de warm-up
app.get('/api/warmup', (req, res) => {
  db.all(
    `SELECT * FROM warmup_sessions ORDER BY started_at DESC`,
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows.map(r => ({
        ...r,
        config: JSON.parse(r.config || '{}'),
        ready: r.current_score >= r.target_score
      })));
    }
  );
});

// Status de uma sessão específica
app.get('/api/warmup/:id', (req, res) => {
  db.get(
    `SELECT * FROM warmup_sessions WHERE id = ?`,
    [req.params.id],
    (err, row) => {
      if (err || !row) return res.status(404).json({ error: 'Sessão não encontrada' });
      
      const config = JSON.parse(row.config || '{}');
      
      // Calcular status de saúde do chip
      const healthScore = calculateHealthScore(row);
      
      res.json({
        ...row,
        config,
        health: healthScore,
        ready: row.current_score >= row.target_score,
        recommendations: getRecommendations(healthScore, row)
      });
    }
  );
});

// Pausar/Retomar warm-up
app.post('/api/warmup/:id/pause', (req, res) => {
  db.run(
    "UPDATE warmup_sessions SET status = 'paused' WHERE id = ?",
    [req.params.id],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Warm-up pausado' });
    }
  );
});

app.post('/api/warmup/:id/resume', (req, res) => {
  db.run(
    "UPDATE warmup_sessions SET status = 'running' WHERE id = ?",
    [req.params.id],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Warm-up retomado' });
    }
  );
});

// Parar warm-up
app.post('/api/warmup/:id/stop', (req, res) => {
  db.run(
    "UPDATE warmup_sessions SET status = 'stopped', completed_at = datetime('now') WHERE id = ?",
    [req.params.id],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Warm-up finalizado' });
    }
  );
});

// ========== WARM-UP BUDDIES (NÚMEROS CONTROLADOS) ==========

// Listar buddies
app.get('/api/warmup-buddies', (req, res) => {
  db.all(
    "SELECT * FROM warmup_buddies ORDER BY created_at DESC",
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    }
  );
});

// Adicionar buddy
app.post('/api/warmup-buddies', (req, res) => {
  const { name, phone } = req.body;

  if (!phone) return res.status(400).json({ error: 'Telefone obrigatório' });

  // Limpar número
  const cleanPhone = phone.replace(/\D/g, '');

  db.run(
    "INSERT INTO warmup_buddies (name, phone) VALUES (?, ?)",
    [name || 'Buddy', cleanPhone],
    function(err) {
      if (err) {
        if (err.message.includes('UNIQUE')) {
          return res.status(400).json({ error: 'Número já cadastrado' });
        }
        return res.status(500).json({ error: err.message });
      }
      res.json({ id: this.lastID, message: 'Buddy adicionado' });
    }
  );
});

// Remover buddy
app.delete('/api/warmup-buddies/:id', (req, res) => {
  db.run(
    "DELETE FROM warmup_buddies WHERE id = ?",
    [req.params.id],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Buddy removido' });
    }
  );
});

// Listar logs de uma sessão
app.get('/api/warmup/:id/logs', (req, res) => {
  db.all(
    "SELECT * FROM warmup_logs WHERE session_id = ? ORDER BY created_at DESC LIMIT 100",
    [req.params.id],
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    }
  );
});

// Funções auxiliares de warm-up
function calculateHealthScore(session) {
  let score = 0;
  
  // Pontos por mensagens recebidas (engajamento)
  score += Math.min(session.messages_received * 2, 40);
  
  // Pontos por tempo de atividade
  const hoursActive = (Date.now() - new Date(session.started_at).getTime()) / (1000 * 60 * 60);
  score += Math.min(hoursActive * 5, 30);
  
  // Pontos por mensagens enviadas (atividade)
  score += Math.min(session.messages_sent, 20);
  
  // Bônus por estágio avançado
  const stageBonus = { initial: 0, building: 5, active: 10, mature: 15 };
  score += stageBonus[session.stage] || 0;
  
  return Math.min(Math.round(score), 100);
}

function getRecommendations(health, session) {
  const recs = [];
  
  if (health.score < 30) {
    recs.push('🔴 Chip muito frio - Evite envios em massa');
    recs.push('💡 Envie mensagens para contatos que respondem');
    recs.push('💡 Mantenha conversas de 2-3 mensagens');
  } else if (health.score < 60) {
    recs.push('🟡 Chip esquentando - Pode fazer envios leves');
    recs.push('💡 Aumente gradualmente o volume');
    recs.push('💩 Monitore taxa de bloqueio');
  } else {
    recs.push('🟢 Chip pronto! - Pode usar para campanhas');
    recs.push('✅ Mantenha boas práticas de envio');
  }
  
  if (session.messages_sent > 0 && session.messages_received / session.messages_sent < 0.3) {
    recs.push('⚠️ Poucas respostas - Parece spammy');
  }
  
  return recs;
}

// ========== WARM-UP AUTOMÁTICO COM NÚMEROS CONTROLADOS ==========

// Mensagens de conversação natural para warm-up
const WARMUP_MESSAGES = {
  outgoing: [
    "Oi, tudo bem?",
    "E aí, como foi seu dia?",
    "Vi uma coisa hoje que lembrei de você",
    "Que saudade! Quando a gente se vê?",
    "Mandei aquele áudio que falei",
    "Você viu o jogo ontem?",
    "Vamos marcar aquele almoço?",
    "Feliz aniversário atrasado 🎉",
    "Oi! Desculpa sumir, correria total",
    "Te mandei mensagem no outro número",
    "Olha essa foto que achei aqui",
    "Que bom te ver por aqui!",
    "Ainda está usando esse número?",
    "Preciso de uma ajuda sua",
    "Meu celular quebrou, troquei de número"
  ],
  incoming: [
    "Tudo ótimo! E você?",
    "Foi tranquilo, e o seu?",
    "Sério? O que foi?",
    "Também tô com saudade!",
    "Vou ouvir agora",
    "Vi sim! Que jogo",
    "Bora! Quando você pode?",
    "Obrigado! Melhor tarde que nunca 😄",
    "Relaxa, acontece!",
    "Qual é o outro?",
    "Nossa, que nostalgia!",
    "Igualmente! Que surpresa",
    "Sim, uso sim!",
    "Claro! O que precisa?",
    "Ah, entendi! Novo número então"
  ]
};

// Números de "amigos" para simular conversa (configuráveis)
let WARMUP_BUDDY_NUMBERS = [];

// Carregar números de buddies do banco
function loadBuddyNumbers() {
  db.all("SELECT * FROM warmup_buddies WHERE active = 1", (err, rows) => {
    if (!err && rows) {
      WARMUP_BUDDY_NUMBERS = rows.map(r => r.phone);
      console.log(`[Warm-up] ${WARMUP_BUDDY_NUMBERS.length} números de buddies carregados`);
    }
  });
}

// Enviar mensagem real via Evolution
async function sendWarmupMessage(instanceName, toNumber, message) {
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/message/sendText/${instanceName}`,
      { number: toNumber, text: message },
      { 
        headers: { 
          'apikey': EVOLUTION_KEY, 
          'Content-Type': 'application/json' 
        },
        timeout: 30000
      }
    );
    return { success: true, data: response.data };
  } catch (error) {
    console.error(`[Warm-up] Erro ao enviar:`, error.message);
    return { success: false, error: error.message };
  }
}

async function startWarmup(sessionId, instanceName, config) {
  console.log(`[Warm-up] Iniciando sessão ${sessionId} para ${instanceName}`);
  
  // Verificar se há buddies configurados
  if (WARMUP_BUDDY_NUMBERS.length === 0) {
    loadBuddyNumbers();
    // Usar números padrão de exemplo se não houver
    WARMUP_BUDDY_NUMBERS = [
      '5511999999991',
      '5511999999992', 
      '5511999999993',
      '5511999999994',
      '5511999999995'
    ];
  }
  
  // Estágios do warm-up
  const stages = [
    { name: 'initial', days: 1, messagesPerDay: 10, minDelay: 60000, maxDelay: 180000 },
    { name: 'building', days: 2, messagesPerDay: 20, minDelay: 45000, maxDelay: 120000 },
    { name: 'active', days: 2, messagesPerDay: 35, minDelay: 30000, maxDelay: 90000 },
    { name: 'mature', days: 2, messagesPerDay: 50, minDelay: 20000, maxDelay: 60000 }
  ];
  
  let totalMessagesSent = 0;
  let totalMessagesReceived = 0;
  
  for (const stage of stages) {
    console.log(`[Warm-up] Sessão ${sessionId} - Estágio: ${stage.name} (${stage.days} dias)`);
    
    db.run(
      "UPDATE warmup_sessions SET stage = ? WHERE id = ?",
      [stage.name, sessionId]
    );
    
    for (let day = 0; day < stage.days; day++) {
      const dayMessages = stage.messagesPerDay;
      
      console.log(`[Warm-up] Dia ${day + 1} do estágio ${stage.name} - ${dayMessages} mensagens`);
      
      for (let msgCount = 0; msgCount < dayMessages; msgCount++) {
        const sessionStatus = await new Promise((resolve) => {
          db.get(
            "SELECT status FROM warmup_sessions WHERE id = ?",
            [sessionId],
            (err, row) => resolve(row?.status)
          );
        });
        
        if (sessionStatus === 'paused') {
          console.log(`[Warm-up] Sessão ${sessionId} pausada. Aguardando...`);
          await new Promise(r => setTimeout(r, 10000));
          msgCount--;
          continue;
        }
        
        if (sessionStatus === 'stopped') {
          console.log(`[Warm-up] Sessão ${sessionId} parada pelo usuário`);
          return;
        }
        
        const buddy = WARMUP_BUDDY_NUMBERS[Math.floor(Math.random() * WARMUP_BUDDY_NUMBERS.length)];
        const message = WARMUP_MESSAGES.outgoing[Math.floor(Math.random() * WARMUP_MESSAGES.outgoing.length)];
        
        console.log(`[Warm-up] Enviando para ${buddy}: "${message}"`);
        const result = await sendWarmupMessage(instanceName, buddy, message);
        
        if (result.success) {
          totalMessagesSent++;
          db.run(
            "UPDATE warmup_sessions SET messages_sent = ? WHERE id = ?",
            [totalMessagesSent, sessionId]
          );
          
          db.run(
            "INSERT INTO warmup_logs (session_id, action, details) VALUES (?, ?, ?)",
            [sessionId, 'sent', `Para: ${buddy}, Msg: ${message}`]
          );
          
          const replyChance = stage.name === 'initial' ? 0.8 : stage.name === 'building' ? 0.7 : 0.5;
          
          if (Math.random() < replyChance) {
            const replyDelay = 10000 + Math.random() * 50000;
            await new Promise(r => setTimeout(r, replyDelay));
            
            const replyMessage = WARMUP_MESSAGES.incoming[Math.floor(Math.random() * WARMUP_MESSAGES.incoming.length)];
            console.log(`[Warm-up] Resposta recebida de ${buddy}: "${replyMessage}"`);
            
            totalMessagesReceived++;
            db.run(
              "UPDATE warmup_sessions SET messages_received = ? WHERE id = ?",
              [totalMessagesReceived, sessionId]
            );
            
            db.run(
              "INSERT INTO warmup_logs (session_id, action, details) VALUES (?, ?, ?)",
              [sessionId, 'received', `De: ${buddy}, Msg: ${replyMessage}`]
            );
            
            if (Math.random() < 0.3) {
              await new Promise(r => setTimeout(r, 5000 + Math.random() * 10000));
              const followUp = WARMUP_MESSAGES.outgoing[Math.floor(Math.random() * WARMUP_MESSAGES.outgoing.length)];
              await sendWarmupMessage(instanceName, buddy, followUp);
              totalMessagesSent++;
              db.run(
                "UPDATE warmup_sessions SET messages_sent = ? WHERE id = ?",
                [totalMessagesSent, sessionId]
              );
            }
          }
          
          const scorePerMessage = 100 / 200;
          const currentScore = Math.min(Math.round(totalMessagesSent * scorePerMessage), 100);
          const progress = Math.round((totalMessagesSent / 200) * 100);
          
          db.run(
            "UPDATE warmup_sessions SET current_score = ?, progress = ? WHERE id = ?",
            [currentScore, progress, sessionId]
          );
        } else {
          console.error(`[Warm-up] Falha ao enviar mensagem`);
          db.run(
            "INSERT INTO warmup_logs (session_id, action, details) VALUES (?, ?, ?)",
            [sessionId, 'error', `Falha ao enviar para ${buddy}: ${result.error}`]
          );
        }
        
        const delay = stage.minDelay + Math.random() * (stage.maxDelay - stage.minDelay);
        console.log(`[Warm-up] Aguardando ${Math.round(delay/1000)}s antes da próxima...`);
        await new Promise(r => setTimeout(r, delay));
      }
      
      console.log(`[Warm-up] Dia completo. Aguardando próximo dia...`);
      await new Promise(r => setTimeout(r, 10000));
    }
  }
  
  db.run(
    "UPDATE warmup_sessions SET status = 'completed', completed_at = datetime('now'), current_score = 100, progress = 100 WHERE id = ?",
    [sessionId]
  );
  
  console.log(`[Warm-up] Sessão ${sessionId} COMPLETADA! Total: ${totalMessagesSent} enviadas, ${totalMessagesReceived} recebidas`);
}

// ========== STATS ==========

app.get('/api/stats', (req, res) => {
  db.get("SELECT COUNT(*) as total FROM campaigns", (err, campaigns) => {
    db.get("SELECT COUNT(*) as total FROM contacts", (err, contacts) => {
      db.get(`
        SELECT SUM(sent_count) as total_sent,
          SUM(delivered_count) as total_delivered,
          SUM(read_count) as total_read,
          SUM(replied_count) as total_replied
        FROM campaigns
      `, (err, stats) => {
        res.json({
          totalCampaigns: campaigns?.total || 0,
          totalContacts: contacts?.total || 0,
          today: {
            sent: stats?.total_sent || 0,
            delivered: stats?.total_delivered || 0,
            read: stats?.total_read || 0,
            replied: stats?.total_replied || 0
          },
          conversionRates: {
            delivery: stats?.total_sent ? Math.round((stats.total_delivered / stats.total_sent) * 100) : 0,
            read: stats?.total_delivered ? Math.round((stats.total_read / stats.total_delivered) * 100) : 0,
            reply: stats?.total_read ? Math.round((stats.total_replied / stats.total_read) * 100) : 0
          }
        });
      });
    });
  });
});

// Health
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'Agency Marketing API' });
});

app.get('/', (req, res) => {
  res.json({ 
    status: 'ok', 
    service: 'Agency Marketing API',
    version: '2.0.0',
    features: ['Evolution API integration', 'Campaign management', 'Templates', 'Mailing lists']
  });
});

initDB();

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Agency API v2.0 rodando na porta ${PORT}`);
});
