const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const axios = require('axios');

const app = express();
const PORT = 7778;

// Evolution API config
const EVOLUTION_URL = process.env.EVOLUTION_URL || 'http://agency-evolution:8080';
const EVOLUTION_KEY = process.env.EVOLUTION_API_KEY || 'agency-evolution-2024';

app.use(cors());
app.use(express.json());

// Database
const DB_PATH = '/opt/agency/database/agency.db';
const db = new sqlite3.Database(DB_PATH);

// Init database
function initDB() {
  db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS campaigns (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      status TEXT DEFAULT 'draft',
      template_id INTEGER,
      mailing_id INTEGER,
      instance_name TEXT,
      total_recipients INTEGER DEFAULT 0,
      sent_count INTEGER DEFAULT 0,
      delivered_count INTEGER DEFAULT 0,
      read_count INTEGER DEFAULT 0,
      replied_count INTEGER DEFAULT 0,
      failed_count INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS templates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      content TEXT NOT NULL,
      variables TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS mailing_lists (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      total_contacts INTEGER DEFAULT 0,
      valid_contacts INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS contacts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      mailing_id INTEGER,
      phone TEXT NOT NULL,
      name TEXT,
      status TEXT DEFAULT 'pending',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);
  });
}

// ========== EVOLUTION API INTEGRATION ==========

// Listar instâncias
app.get('/api/evolution/instances', async (req, res) => {
  try {
    const response = await axios.get(`${EVOLUTION_URL}/instance/fetchInstances`, {
      headers: { 'apikey': EVOLUTION_KEY }
    });
    res.json(response.data);
  } catch (error) {
    console.error('Evolution error:', error.message);
    res.json({ instances: [] });
  }
});

// Verificar se número existe no WhatsApp
app.post('/api/evolution/instances/:name/check-number', async (req, res) => {
  const { number } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/whatsappNumbers/${req.params.name}`,
      { numbers: [number] },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Check number error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Verificar múltiplos números (bulk)
app.post('/api/evolution/instances/:name/check-numbers', async (req, res) => {
  const { numbers } = req.body; // array de números
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/whatsappNumbers/${req.params.name}`,
      { numbers },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Check numbers error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Obter informações do perfil de um número
app.post('/api/evolution/instances/:name/profile', async (req, res) => {
  const { number } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/fetchProfile/${req.params.name}`,
      { number },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Profile error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Obter foto de perfil
app.post('/api/evolution/instances/:name/profile-picture', async (req, res) => {
  const { number } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/getBase64FromMediaMessage/${req.params.name}`,
      { number, messageId: 'profile' },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Obter status/stories de um número
app.post('/api/evolution/instances/:name/status', async (req, res) => {
  const { number } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/getStatus/${req.params.name}`,
      { number },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Listar todos os contatos da instância
app.get('/api/evolution/instances/:name/contacts', async (req, res) => {
  try {
    const response = await axios.get(
      `${EVOLUTION_URL}/chat/findContacts/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Contacts error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Listar chats/conversas
app.get('/api/evolution/instances/:name/chats', async (req, res) => {
  try {
    const response = await axios.get(
      `${EVOLUTION_URL}/chat/findChats/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Chats error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Obter mensagens de um chat
app.post('/api/evolution/instances/:name/messages', async (req, res) => {
  const { number, limit = 50 } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/findMessages/${req.params.name}`,
      { number, limit },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Enviar mensagem de texto
app.post('/api/evolution/instances/:name/send-text', async (req, res) => {
  const { number, text } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/message/sendText/${req.params.name}`,
      { number, text },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Send text error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Enviar imagem
app.post('/api/evolution/instances/:name/send-image', async (req, res) => {
  const { number, image, caption } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/message/sendMedia/${req.params.name}`,
      { number, media: image, caption, mediaType: 'image' },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Enviar documento/PDF
app.post('/api/evolution/instances/:name/send-document', async (req, res) => {
  const { number, document, caption, fileName } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/message/sendMedia/${req.params.name}`,
      { number, media: document, caption, fileName, mediaType: 'document' },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Enviar áudio
app.post('/api/evolution/instances/:name/send-audio', async (req, res) => {
  const { number, audio } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/message/sendWhatsAppAudio/${req.params.name}`,
      { number, audio },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Enviar localização
app.post('/api/evolution/instances/:name/send-location', async (req, res) => {
  const { number, latitude, longitude, title, address } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/message/sendLocation/${req.params.name}`,
      { number, latitude, longitude, title, address },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Enviar botões interativos
app.post('/api/evolution/instances/:name/send-buttons', async (req, res) => {
  const { number, title, description, footer, buttons } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/message/sendButtons/${req.params.name}`,
      { number, title, description, footer, buttons },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Enviar lista de opções
app.post('/api/evolution/instances/:name/send-list', async (req, res) => {
  const { number, title, description, buttonText, sections } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/message/sendList/${req.params.name}`,
      { number, title, description, buttonText, sections },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Presença (typing...)
app.post('/api/evolution/instances/:name/presence', async (req, res) => {
  const { number, presence } = req.body; // presence: 'composing', 'paused', 'available'
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/sendPresence/${req.params.name}`,
      { number, presence },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Arquivar chat
app.post('/api/evolution/instances/:name/archive', async (req, res) => {
  const { number, archive = true } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/archiveChat/${req.params.name}`,
      { number, archive },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Fixar chat
app.post('/api/evolution/instances/:name/pin', async (req, res) => {
  const { number, pin = true } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/pinChat/${req.params.name}`,
      { number, pin },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Marcar como não lido
app.post('/api/evolution/instances/:name/mark-unread', async (req, res) => {
  const { number } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/markChatUnread/${req.params.name}`,
      { number },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Bloquear contato
app.post('/api/evolution/instances/:name/block', async (req, res) => {
  const { number, block = true } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/blockUser/${req.params.name}`,
      { number, status: block ? 'block' : 'unblock' },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Obter informações do grupo
app.post('/api/evolution/instances/:name/group-info', async (req, res) => {
  const { groupId } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/findGroupInfos/${req.params.name}`,
      { groupJid: groupId },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Listar participantes do grupo
app.post('/api/evolution/instances/:name/group-participants', async (req, res) => {
  const { groupId } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/findParticipants/${req.params.name}`,
      { groupJid: groupId },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Atualizar nome do grupo
app.post('/api/evolution/instances/:name/group-update-name', async (req, res) => {
  const { groupId, subject } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/updateGroupName/${req.params.name}`,
      { groupJid: groupId, subject },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Atualizar descrição do grupo
app.post('/api/evolution/instances/:name/group-update-description', async (req, res) => {
  const { groupId, description } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/updateGroupDescription/${req.params.name}`,
      { groupJid: groupId, description },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Atualizar foto do grupo
app.post('/api/evolution/instances/:name/group-update-picture', async (req, res) => {
  const { groupId, image } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/updateGroupPicture/${req.params.name}`,
      { groupJid: groupId, image },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Sair do grupo
app.post('/api/evolution/instances/:name/group-leave', async (req, res) => {
  const { groupId } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/leaveGroup/${req.params.name}`,
      { groupJid: groupId },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Criar grupo
app.post('/api/evolution/instances/:name/group-create', async (req, res) => {
  const { subject, description, participants } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/create/${req.params.name}`,
      { subject, description, participants },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Adicionar participantes ao grupo
app.post('/api/evolution/instances/:name/group-add-participants', async (req, res) => {
  const { groupId, participants } = req.body; // participants: array de números
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/updateParticipant/${req.params.name}`,
      { groupJid: groupId, action: 'add', participants },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Remover participantes do grupo
app.post('/api/evolution/instances/:name/group-remove-participants', async (req, res) => {
  const { groupId, participants } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/updateParticipant/${req.params.name}`,
      { groupJid: groupId, action: 'remove', participants },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Promover a admin
app.post('/api/evolution/instances/:name/group-promote', async (req, res) => {
  const { groupId, participants } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/updateParticipant/${req.params.name}`,
      { groupJid: groupId, action: 'promote', participants },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Rebaixar admin
app.post('/api/evolution/instances/:name/group-demote', async (req, res) => {
  const { groupId, participants } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/updateParticipant/${req.params.name}`,
      { groupJid: groupId, action: 'demote', participants },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Gerar link de convite do grupo
app.post('/api/evolution/instances/:name/group-invite-link', async (req, res) => {
  const { groupId, reset = false } = req.body;
  try {
    const url = reset 
      ? `${EVOLUTION_URL}/group/revokeInviteCode/${req.params.name}`
      : `${EVOLUTION_URL}/group/inviteCode/${req.params.name}`;
    const response = await axios.post(
      url,
      { groupJid: groupId },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Configurações do grupo
app.post('/api/evolution/instances/:name/group-settings', async (req, res) => {
  const { groupId, setting, value } = req.body; // setting: 'announcement', 'restrict', etc
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/group/toggleEphemeral/${req.params.name}`,
      { groupJid: groupId, expiration: value },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Criar instância
app.post('/api/evolution/instances', async (req, res) => {
  const { name, description } = req.body;
  try {
    const response = await axios.post(`${EVOLUTION_URL}/instance/create`, {
      instanceName: name,
      description: description || '',
      qrcode: true,
      number: ''
    }, {
      headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' }
    });
    res.json(response.data);
  } catch (error) {
    console.error('Create instance error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Conectar (QR Code)
app.get('/api/evolution/instances/:name/connect', async (req, res) => {
  try {
    const response = await axios.get(
      `${EVOLUTION_URL}/instance/connect/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Connect error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Status
app.get('/api/evolution/instances/:name/status', async (req, res) => {
  try {
    const response = await axios.get(
      `${EVOLUTION_URL}/instance/connectionState/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Logout
app.post('/api/evolution/instances/:name/logout', async (req, res) => {
  try {
    const response = await axios.delete(
      `${EVOLUTION_URL}/instance/logout/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Deletar
app.delete('/api/evolution/instances/:name', async (req, res) => {
  try {
    const response = await axios.delete(
      `${EVOLUTION_URL}/instance/delete/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Enviar mensagem
app.post('/api/evolution/instances/:name/send', async (req, res) => {
  const { number, message } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/message/sendText/${req.params.name}`,
      { number, text: message },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Criar instância
app.post('/api/evolution/instances', async (req, res) => {
  const { name, description } = req.body;
  try {
    const response = await axios.post(`${EVOLUTION_URL}/instance/create`, {
      instanceName: name,
      description: description || '',
      qrcode: true,
      number: ''
    }, {
      headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' }
    });
    res.json(response.data);
  } catch (error) {
    console.error('Create instance error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Conectar (QR Code)
app.get('/api/evolution/instances/:name/connect', async (req, res) => {
  try {
    const response = await axios.get(
      `${EVOLUTION_URL}/instance/connect/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Connect error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Status da conexão
app.get('/api/evolution/instances/:name/connection', async (req, res) => {
  try {
    const response = await axios.get(
      `${EVOLUTION_URL}/instance/connectionState/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Logout
app.post('/api/evolution/instances/:name/logout', async (req, res) => {
  try {
    const response = await axios.delete(
      `${EVOLUTION_URL}/instance/logout/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Deletar instância
app.delete('/api/evolution/instances/:name', async (req, res) => {
  try {
    const response = await axios.delete(
      `${EVOLUTION_URL}/instance/delete/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ========== TEMPLATES ==========

app.get('/api/templates', (req, res) => {
  db.all("SELECT * FROM templates ORDER BY created_at DESC", (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/templates', (req, res) => {
  const { name, content, variables } = req.body;
  db.run(
    "INSERT INTO templates (name, content, variables) VALUES (?, ?, ?)",
    [name, content, JSON.stringify(variables || [])],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID, message: 'Template criado' });
    }
  );
});

app.delete('/api/templates/:id', (req, res) => {
  db.run("DELETE FROM templates WHERE id = ?", [req.params.id], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: 'Template deletado' });
  });
});

// ========== MAILING ==========

app.get('/api/mailing', (req, res) => {
  db.all("SELECT * FROM mailing_lists ORDER BY created_at DESC", (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/mailing', (req, res) => {
  const { name } = req.body;
  db.run("INSERT INTO mailing_lists (name) VALUES (?)", [name], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ id: this.lastID, message: 'Lista criada' });
  });
});

app.get('/api/mailing/:id/contacts', (req, res) => {
  db.all("SELECT * FROM contacts WHERE mailing_id = ?", [req.params.id], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/mailing/:id/contacts', (req, res) => {
  const { contacts } = req.body;
  const stmt = db.prepare("INSERT INTO contacts (mailing_id, phone, name) VALUES (?, ?, ?)");
  let count = 0;
  
  contacts.forEach(c => {
    stmt.run(req.params.id, c.phone, c.name);
    count++;
  });
  stmt.finalize();
  
  db.run(
    "UPDATE mailing_lists SET total_contacts = (SELECT COUNT(*) FROM contacts WHERE mailing_id = ?) WHERE id = ?",
    [req.params.id, req.params.id]
  );
  
  res.json({ imported: count });
});

app.delete('/api/mailing/:id', (req, res) => {
  db.run("DELETE FROM contacts WHERE mailing_id = ?", [req.params.id], () => {
    db.run("DELETE FROM mailing_lists WHERE id = ?", [req.params.id], function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Lista deletada' });
    });
  });
});

// ========== CAMPANHAS ==========

app.get('/api/campaigns', (req, res) => {
  db.all(`
    SELECT c.*, t.name as template_name, m.name as mailing_name
    FROM campaigns c
    LEFT JOIN templates t ON c.template_id = t.id
    LEFT JOIN mailing_lists m ON c.mailing_id = m.id
    ORDER BY c.created_at DESC
  `, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/campaigns', (req, res) => {
  const { name, template_id, mailing_id, instance_name } = req.body;
  
  db.get("SELECT COUNT(*) as count FROM contacts WHERE mailing_id = ?", [mailing_id], (err, row) => {
    const total = row.count;
    
    db.run(
      "INSERT INTO campaigns (name, template_id, mailing_id, instance_name, total_recipients) VALUES (?, ?, ?, ?, ?)",
      [name, template_id, mailing_id, instance_name, total],
      function(err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ id: this.lastID, message: 'Campanha criada', total_recipients: total });
      }
    );
  });
});

// Iniciar campanha
app.post('/api/campaigns/:id/start', async (req, res) => {
  const campaignId = req.params.id;
  
  db.get(`
    SELECT c.*, t.content as template_content
    FROM campaigns c
    LEFT JOIN templates t ON c.template_id = t.id
    WHERE c.id = ?
  `, [campaignId], async (err, campaign) => {
    if (err || !campaign) {
      return res.status(404).json({ error: 'Campanha não encontrada' });
    }
    
    db.all("SELECT * FROM contacts WHERE mailing_id = ?", [campaign.mailing_id], async (err, contacts) => {
      if (contacts.length === 0) {
        return res.status(400).json({ error: 'Nenhum contato' });
      }
      
      db.run("UPDATE campaigns SET status = 'running' WHERE id = ?", [campaignId]);
      
      res.json({ message: 'Campanha iniciada', total: contacts.length });
      
      // Enviar em background
      sendMessages(campaign, contacts);
    });
  });
});

async function sendMessages(campaign, contacts) {
  let sent = 0;
  let failed = 0;
  
  for (const contact of contacts) {
    try {
      let message = campaign.template_content;
      message = message.replace(/{{nome}}/g, contact.name || '');
      message = message.replace(/{{telefone}}/g, contact.phone);
      
      await axios.post(
        `${EVOLUTION_URL}/message/sendText/${campaign.instance_name}`,
        { number: contact.phone, text: message },
        { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
      );
      
      sent++;
      db.run("UPDATE campaigns SET sent_count = ? WHERE id = ?", [sent, campaign.id]);
      
      await new Promise(r => setTimeout(r, 5000 + Math.random() * 5000));
    } catch (error) {
      failed++;
      console.error('Erro:', error.message);
    }
  }
  
  db.run("UPDATE campaigns SET status = 'completed', sent_count = ?, failed_count = ? WHERE id = ?",
    [sent, failed, campaign.id]);
}

app.delete('/api/campaigns/:id', (req, res) => {
  db.run("DELETE FROM campaigns WHERE id = ?", [req.params.id], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: 'Campanha deletada' });
  });
});

// ========== STATS ==========

app.get('/api/stats', (req, res) => {
  db.get("SELECT COUNT(*) as total FROM campaigns", (err, campaigns) => {
    db.get("SELECT COUNT(*) as total FROM contacts", (err, contacts) => {
      db.get(`
        SELECT SUM(sent_count) as total_sent,
          SUM(delivered_count) as total_delivered,
          SUM(read_count) as total_read,
          SUM(replied_count) as total_replied
        FROM campaigns
      `, (err, stats) => {
        res.json({
          totalCampaigns: campaigns?.total || 0,
          totalContacts: contacts?.total || 0,
          today: {
            sent: stats?.total_sent || 0,
            delivered: stats?.total_delivered || 0,
            read: stats?.total_read || 0,
            replied: stats?.total_replied || 0
          },
          conversionRates: {
            delivery: stats?.total_sent ? Math.round((stats.total_delivered / stats.total_sent) * 100) : 0,
            read: stats?.total_delivered ? Math.round((stats.total_read / stats.total_delivered) * 100) : 0,
            reply: stats?.total_read ? Math.round((stats.total_replied / stats.total_read) * 100) : 0
          }
        });
      });
    });
  });
});

// Health
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'Agency Marketing API' });
});

app.get('/', (req, res) => {
  res.json({ 
    status: 'ok', 
    service: 'Agency Marketing API',
    version: '2.0.0',
    features: ['Evolution API integration', 'Campaign management', 'Templates', 'Mailing lists']
  });
});

initDB();

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Agency API v2.0 rodando na porta ${PORT}`);
});
