const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const axios = require('axios');

const app = express();
const PORT = 7778;

// Evolution API config
const EVOLUTION_URL = process.env.EVOLUTION_URL || 'http://evolution-whatsapp:8080';
const EVOLUTION_KEY = process.env.EVOLUTION_API_KEY || 'criativalia2024';

app.use(cors());
app.use(express.json());

// Database
const DB_PATH = '/opt/agency/database/agency.db';
const db = new sqlite3.Database(DB_PATH);

// Init database
function initDB() {
  db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS campaigns (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      status TEXT DEFAULT 'draft',
      template_id INTEGER,
      mailing_id INTEGER,
      instance_name TEXT,
      total_recipients INTEGER DEFAULT 0,
      sent_count INTEGER DEFAULT 0,
      delivered_count INTEGER DEFAULT 0,
      read_count INTEGER DEFAULT 0,
      replied_count INTEGER DEFAULT 0,
      failed_count INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS templates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      content TEXT NOT NULL,
      variables TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS mailing_lists (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      total_contacts INTEGER DEFAULT 0,
      valid_contacts INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    db.run(`CREATE TABLE IF NOT EXISTS contacts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      mailing_id INTEGER,
      phone TEXT NOT NULL,
      name TEXT,
      status TEXT DEFAULT 'pending',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Tabela de warm-up de chips
    db.run(`CREATE TABLE IF NOT EXISTS warmup_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      instance_name TEXT NOT NULL,
      status TEXT DEFAULT 'running',
      stage TEXT DEFAULT 'initial',
      progress INTEGER DEFAULT 0,
      target_score INTEGER DEFAULT 100,
      current_score INTEGER DEFAULT 0,
      messages_sent INTEGER DEFAULT 0,
      messages_received INTEGER DEFAULT 0,
      started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      completed_at DATETIME,
      config TEXT
    )`);

    // Tabela de logs de warm-up
    db.run(`CREATE TABLE IF NOT EXISTS warmup_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id INTEGER,
      action TEXT,
      details TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Tabela de números buddies para warm-up
    db.run(`CREATE TABLE IF NOT EXISTS warmup_buddies (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      phone TEXT NOT NULL UNIQUE,
      active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);
  });
}

// ========== EVOLUTION API INTEGRATION ==========

// Listar instâncias
app.get('/api/evolution/instances', async (req, res) => {
  try {
    const response = await axios.get(`${EVOLUTION_URL}/instance/fetchInstances`, {
      headers: { 'apikey': EVOLUTION_KEY }
    });
    res.json(response.data);
  } catch (error) {
    console.error('Evolution error:', error.message);
    res.json({ instances: [] });
  }
});

// Criar instância
app.post('/api/evolution/instances', async (req, res) => {
  const { name } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/instance/create`,
      {
        instanceName: name,
        qrcode: true
        // Não enviar number, token, webhook - deixar a Evolution gerenciar
      },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Create instance error:', error.message);
    if (error.response) {
      console.error('Response data:', error.response.data);
      return res.status(error.response.status).json({ 
        error: error.message,
        details: error.response.data 
      });
    }
    res.status(500).json({ error: error.message });
  }
});

// Conectar (QR Code)
app.get('/api/evolution/:name/connect', async (req, res) => {
  try {
    const response = await axios.get(
      `${EVOLUTION_URL}/instance/connect/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    
    // Normalizar a resposta - Evolution retorna em response.data.qrcode
    const data = response.data;
    
    // Formato da Evolution: { qrcode: { base64: "...", code: "...", pairingCode: "..." } }
    if (data.qrcode) {
      const result = {};
      if (data.qrcode.base64) result.base64 = data.qrcode.base64;
      if (data.qrcode.code) result.code = data.qrcode.code;
      if (data.qrcode.pairingCode) result.pairingCode = data.qrcode.pairingCode;
      res.json(result);
    }
    // Fallback para outros formatos
    else if (data.base64) {
      res.json({ base64: data.base64 });
    }
    else if (data.code) {
      res.json({ code: data.code });
    }
    else {
      console.log('[QR Code] Formato não reconhecido:', JSON.stringify(data).substring(0, 200));
      res.json(data);
    }
  } catch (error) {
    console.error('Connect error:', error.message);
    
    // Tratar erros específicos da Evolution API
    if (error.response) {
      const status = error.response.status;
      const errorData = error.response.data;
      
      if (status === 404) {
        return res.status(404).json({ 
          error: 'Instância não encontrada na Evolution API',
          details: 'A instância pode ter sido deletada ou não existe. Crie uma nova instância.'
        });
      }
      
      if (status === 400) {
        return res.status(400).json({
          error: 'Instância já conectada ou erro de configuração',
          details: errorData
        });
      }
      
      return res.status(status).json({
        error: `Erro na Evolution API: ${status}`,
        details: errorData
      });
    }
    
    res.status(500).json({ error: error.message });
  }
});

// Logout
app.post('/api/evolution/:name/logout', async (req, res) => {
  try {
    const response = await axios.delete(
      `${EVOLUTION_URL}/instance/logout/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Logout error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Deletar instância
app.delete('/api/evolution/:name', async (req, res) => {
  try {
    const response = await axios.delete(
      `${EVOLUTION_URL}/instance/delete/${req.params.name}`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Delete error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Verificar se número existe no WhatsApp
app.post('/api/evolution/instances/:name/check-number', async (req, res) => {
  const { number } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/whatsappNumbers/${req.params.name}`,
      { numbers: [number] },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Check number error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Verificar múltiplos números (bulk)
app.post('/api/evolution/instances/:name/check-numbers', async (req, res) => {
  const { numbers } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/whatsappNumbers/${req.params.name}`,
      { numbers },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Check numbers error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Obter perfil
app.post('/api/evolution/instances/:name/profile', async (req, res) => {
  const { number } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/chat/fetchProfile/${req.params.name}`,
      { number },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Profile error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// Enviar mensagem de texto
app.post('/api/evolution/instances/:name/send-text', async (req, res) => {
  const { number, text } = req.body;
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/message/sendText/${req.params.name}`,
      { number, text },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
    );
    res.json(response.data);
  } catch (error) {
    console.error('Send text error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// ========== TEMPLATES ==========

app.get('/api/templates', (req, res) => {
  db.all("SELECT * FROM templates ORDER BY created_at DESC", (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/templates', (req, res) => {
  const { name, content } = req.body;
  db.run(
    "INSERT INTO templates (name, content) VALUES (?, ?)",
    [name, content],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID, message: 'Template criado' });
    }
  );
});

app.delete('/api/templates/:id', (req, res) => {
  db.run("DELETE FROM templates WHERE id = ?", [req.params.id], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: 'Template deletado' });
  });
});

// ========== MAILING LISTS ==========

app.get('/api/mailing', (req, res) => {
  db.all("SELECT * FROM mailing_lists ORDER BY created_at DESC", (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/mailing', (req, res) => {
  const { name } = req.body;
  db.run(
    "INSERT INTO mailing_lists (name) VALUES (?)",
    [name],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID, message: 'Lista criada' });
    }
  );
});

app.get('/api/mailing/:id/contacts', (req, res) => {
  db.all("SELECT * FROM contacts WHERE mailing_id = ?", [req.params.id], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.delete('/api/mailing/:id', (req, res) => {
  db.run("DELETE FROM contacts WHERE mailing_id = ?", [req.params.id], function(err) {
    db.run("DELETE FROM mailing_lists WHERE id = ?", [req.params.id], function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Lista deletada' });
    });
  });
});

// ========== UPLOAD CSV ==========

app.post('/api/mailing/:id/upload-csv', express.json({ limit: '10mb' }), (req, res) => {
  const mailingId = req.params.id;
  const { csvData } = req.body;
  
  if (!csvData) {
    return res.status(400).json({ error: 'Dados CSV não fornecidos' });
  }
  
  const lines = csvData.trim().split('\n');
  const contacts = [];
  let format = 'unknown';
  
  const firstLine = lines[0].toLowerCase();
  if (firstLine.includes('nome') && firstLine.includes('telefone')) {
    format = 'nome-telefone';
  } else if (firstLine.includes('name') && firstLine.includes('phone')) {
    format = 'name-phone';
  } else if (firstLine.includes('telefone') || firstLine.includes('phone') || firstLine.includes('numero')) {
    format = 'telefone-only';
  } else if (lines[0].includes(',')) {
    format = 'csv-raw';
  }
  
  const startIndex = (format === 'nome-telefone' || format === 'name-phone' || format === 'telefone-only') ? 1 : 0;
  
  for (let i = startIndex; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    
    const parts = line.split(',').map(p => p.trim());
    
    if (format === 'nome-telefone' || format === 'name-phone') {
      const name = parts[0];
      const phone = parts[1]?.replace(/\D/g, '');
      if (phone && phone.length >= 10) {
        contacts.push({ name, phone });
      }
    } else if (format === 'telefone-only') {
      const phone = parts[0]?.replace(/\D/g, '');
      if (phone && phone.length >= 10) {
        contacts.push({ name: '', phone });
      }
    } else {
      const phone = parts.find(p => p.replace(/\D/g, '').length >= 10)?.replace(/\D/g, '');
      const name = parts.find(p => p.replace(/\D/g, '').length < 10 && p.length > 2) || '';
      if (phone) {
        contacts.push({ name, phone });
      }
    }
  }
  
  let inserted = 0;
  const stmt = db.prepare("INSERT INTO contacts (mailing_id, phone, name) VALUES (?, ?, ?)");
  
  contacts.forEach(contact => {
    stmt.run(mailingId, contact.phone, contact.name);
    inserted++;
  });
  
  stmt.finalize();
  
  db.run(
    "UPDATE mailing_lists SET total_contacts = total_contacts + ? WHERE id = ?",
    [inserted, mailingId]
  );
  
  res.json({
    message: `${inserted} contatos importados`,
    total: inserted,
    format: format,
    sample: contacts.slice(0, 3)
  });
});

// ========== CAMPAIGNS ==========

app.get('/api/campaigns', (req, res) => {
  db.all(`
    SELECT c.*, t.name as template_name, m.name as mailing_name
    FROM campaigns c
    LEFT JOIN templates t ON c.template_id = t.id
    LEFT JOIN mailing_lists m ON c.mailing_id = m.id
    ORDER BY c.created_at DESC
  `, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/campaigns', (req, res) => {
  const { name, instance_name, template_id, mailing_id } = req.body;
  
  db.get("SELECT COUNT(*) as total FROM contacts WHERE mailing_id = ?", [mailing_id], (err, row) => {
    const total = row?.total || 0;
    
    db.run(
      `INSERT INTO campaigns (name, instance_name, template_id, mailing_id, total_recipients, status)
       VALUES (?, ?, ?, ?, ?, 'draft')`,
      [name, instance_name, template_id, mailing_id, total],
      function(err) {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ id: this.lastID, message: 'Campanha criada', total_recipients: total });
      }
    );
  });
});

app.post('/api/campaigns/:id/start', async (req, res) => {
  const campaignId = req.params.id;
  
  db.get(`
    SELECT c.*, t.content as template_content
    FROM campaigns c
    LEFT JOIN templates t ON c.template_id = t.id
    WHERE c.id = ?
  `, [campaignId], async (err, campaign) => {
    if (err || !campaign) {
      return res.status(404).json({ error: 'Campanha não encontrada' });
    }
    
    db.all("SELECT * FROM contacts WHERE mailing_id = ?", [campaign.mailing_id], async (err, contacts) => {
      if (contacts.length === 0) {
        return res.status(400).json({ error: 'Nenhum contato' });
      }
      
      db.run("UPDATE campaigns SET status = 'running' WHERE id = ?", [campaignId]);
      
      res.json({ message: 'Campanha iniciada', total: contacts.length });
      
      sendMessages(campaign, contacts);
    });
  });
});

async function sendMessages(campaign, contacts) {
  let sent = 0;
  let failed = 0;
  
  for (const contact of contacts) {
    try {
      let message = campaign.template_content;
      message = message.replace(/{{nome}}/g, contact.name || '');
      message = message.replace(/{{telefone}}/g, contact.phone);
      
      await axios.post(
        `${EVOLUTION_URL}/message/sendText/${campaign.instance_name}`,
        { number: contact.phone, text: message },
        { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' } }
      );
      
      sent++;
      db.run("UPDATE campaigns SET sent_count = ? WHERE id = ?", [sent, campaign.id]);
      
      await new Promise(r => setTimeout(r, 5000 + Math.random() * 5000));
    } catch (error) {
      failed++;
      console.error('Erro:', error.message);
    }
  }
  
  db.run("UPDATE campaigns SET status = 'completed', sent_count = ?, failed_count = ? WHERE id = ?",
    [sent, failed, campaign.id]);
}

app.delete('/api/campaigns/:id', (req, res) => {
  db.run("DELETE FROM campaigns WHERE id = ?", [req.params.id], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.json({ message: 'Campanha deletada' });
  });
});

// ========== WARM-UP ==========

app.get('/api/warmup', (req, res) => {
  db.all(
    `SELECT * FROM warmup_sessions ORDER BY started_at DESC`,
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows.map(r => ({
        ...r,
        config: JSON.parse(r.config || '{}'),
        ready: r.current_score >= r.target_score
      })));
    }
  );
});

app.get('/api/warmup/:id', (req, res) => {
  db.get(
    `SELECT * FROM warmup_sessions WHERE id = ?`,
    [req.params.id],
    (err, row) => {
      if (err || !row) return res.status(404).json({ error: 'Sessão não encontrada' });
      
      const config = JSON.parse(row.config || '{}');
      const healthScore = calculateHealthScore(row);
      
      res.json({
        ...row,
        config,
        health: healthScore,
        ready: row.current_score >= row.target_score,
        recommendations: getRecommendations(healthScore, row)
      });
    }
  );
});

app.post('/api/warmup/start', (req, res) => {
  const { instance_name, instances, config } = req.body;
  
  if (!instance_name && (!instances || instances.length === 0)) {
    return res.status(400).json({ error: 'Nome da instância ou lista de instâncias obrigatório' });
  }
  
  const allInstances = instances && instances.length > 0 ? instances : [instance_name];
  
  const defaultConfig = {
    messagesPerDay: 50,
    minDelay: 30000,
    maxDelay: 120000,
    stages: ['initial', 'building', 'active', 'mature'],
    currentStage: 'initial',
    instances: allInstances
  };
  
  const finalConfig = JSON.stringify({ ...defaultConfig, ...config, instances: allInstances });
  
  db.run(
    `INSERT INTO warmup_sessions (instance_name, status, stage, progress, config)
     VALUES (?, 'running', 'initial', 0, ?)`,
    [allInstances[0], finalConfig],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      
      const sessionId = this.lastID;
      
      startWarmup(sessionId, allInstances[0], { ...defaultConfig, ...config, instances: allInstances });
      
      res.json({
        id: sessionId,
        message: `Warm-up iniciado com ${allInstances.length} instância(s)`,
        instances: allInstances,
        status: 'running'
      });
    }
  );
});

app.post('/api/warmup/:id/pause', (req, res) => {
  db.run(
    "UPDATE warmup_sessions SET status = 'paused' WHERE id = ?",
    [req.params.id],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Warm-up pausado' });
    }
  );
});

app.post('/api/warmup/:id/resume', (req, res) => {
  db.run(
    "UPDATE warmup_sessions SET status = 'running' WHERE id = ?",
    [req.params.id],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Warm-up retomado' });
    }
  );
});

app.post('/api/warmup/:id/stop', (req, res) => {
  db.run(
    "UPDATE warmup_sessions SET status = 'stopped', completed_at = datetime('now') WHERE id = ?",
    [req.params.id],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Warm-up finalizado' });
    }
  );
});

// ========== WARM-UP BUDDIES ==========

app.get('/api/warmup-buddies', (req, res) => {
  db.all(
    "SELECT * FROM warmup_buddies ORDER BY created_at DESC",
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    }
  );
});

app.post('/api/warmup-buddies', (req, res) => {
  const { name, phone } = req.body;
  
  if (!phone) return res.status(400).json({ error: 'Telefone obrigatório' });
  
  const cleanPhone = phone.replace(/\D/g, '');
  
  db.run(
    "INSERT INTO warmup_buddies (name, phone) VALUES (?, ?)",
    [name || 'Buddy', cleanPhone],
    function(err) {
      if (err) {
        if (err.message.includes('UNIQUE')) {
          return res.status(400).json({ error: 'Número já cadastrado' });
        }
        return res.status(500).json({ error: err.message });
      }
      res.json({ id: this.lastID, message: 'Buddy adicionado' });
    }
  );
});

app.delete('/api/warmup-buddies/:id', (req, res) => {
  db.run(
    "DELETE FROM warmup_buddies WHERE id = ?",
    [req.params.id],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ message: 'Buddy removido' });
    }
  );
});

app.get('/api/warmup/:id/logs', (req, res) => {
  db.all(
    "SELECT * FROM warmup_logs WHERE session_id = ? ORDER BY created_at DESC LIMIT 100",
    [req.params.id],
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    }
  );
});

// Funções auxiliares de warm-up
function calculateHealthScore(session) {
  let score = 0;
  score += Math.min(session.messages_received * 2, 40);
  const hoursActive = (Date.now() - new Date(session.started_at).getTime()) / (1000 * 60 * 60);
  score += Math.min(hoursActive * 5, 30);
  score += Math.min(session.messages_sent, 20);
  const stageBonus = { initial: 0, building: 5, active: 10, mature: 15 };
  score += stageBonus[session.stage] || 0;
  return Math.min(Math.round(score), 100);
}

function getRecommendations(health, session) {
  const recs = [];
  if (health.score < 30) {
    recs.push('🔴 Chip muito frio - Evite envios em massa');
  } else if (health.score < 60) {
    recs.push('🟡 Chip esquentando - Pode fazer envios leves');
  } else {
    recs.push('🟢 Chip pronto! - Pode usar para campanhas');
  }
  return recs;
}

// ========== WARM-UP MULTI-INSTÂNCIA ==========

const WARMUP_MESSAGES = {
  outgoing: [
    "Oi, tudo bem?", "E aí, como foi seu dia?", "Vi uma coisa hoje que lembrei de você",
    "Que saudade! Quando a gente se vê?", "Mandei aquele áudio que falei", "Você viu o jogo ontem?",
    "Vamos marcar aquele almoço?", "Feliz aniversário atrasado 🎉", "Oi! Desculpa sumir, correria total",
    "Te mandei mensagem no outro número", "Olha essa foto que achei aqui", "Que bom te ver por aqui!",
    "Ainda está usando esse número?", "Preciso de uma ajuda sua", "Meu celular quebrou, troquei de número"
  ],
  incoming: [
    "Tudo ótimo! E você?", "Foi tranquilo, e o seu?", "Sério? O que foi?", "Também tô com saudade!",
    "Vou ouvir agora", "Vi sim! Que jogo", "Bora! Quando você pode?", "Obrigado! Melhor tarde que nunca 😄",
    "Relaxa, acontece!", "Qual é o outro?", "Nossa, que nostalgia!", "Igualmente! Que surpresa",
    "Sim, uso sim!", "Claro! O que precisa?", "Ah, entendi! Novo número então"
  ]
};

const instanceNumbersCache = {};

async function getInstanceNumber(instanceName) {
  if (instanceNumbersCache[instanceName]) {
    return instanceNumbersCache[instanceName];
  }
  
  try {
    const response = await axios.get(
      `${EVOLUTION_URL}/instance/fetchInstances`,
      { headers: { 'apikey': EVOLUTION_KEY } }
    );
    
    const instance = response.data?.instances?.find(i => i.instanceName === instanceName);
    if (instance?.number) {
      instanceNumbersCache[instanceName] = instance.number;
      return instance.number;
    }
    return null;
  } catch (error) {
    console.error(`[Warm-up] Erro ao obter número da instância ${instanceName}:`, error.message);
    return null;
  }
}

async function sendWarmupMessage(instanceName, toNumber, message) {
  try {
    const response = await axios.post(
      `${EVOLUTION_URL}/message/sendText/${instanceName}`,
      { number: toNumber, text: message },
      { headers: { 'apikey': EVOLUTION_KEY, 'Content-Type': 'application/json' }, timeout: 30000 }
    );
    return { success: true, data: response.data };
  } catch (error) {
    console.error(`[Warm-up] Erro ao enviar:`, error.message);
    return { success: false, error: error.message };
  }
}

async function startWarmup(sessionId, primaryInstance, config) {
  const instances = config.instances || [primaryInstance];
  
  console.log(`[Warm-up] Iniciando sessão ${sessionId} com ${instances.length} instância(s)`);
  console.log(`[Warm-up] Instâncias: ${instances.join(', ')}`);
  
  // Obter números de todas as instâncias
  const instanceNumbers = {};
  for (const inst of instances) {
    const num = await getInstanceNumber(inst);
    if (num) {
      instanceNumbers[inst] = num;
      console.log(`[Warm-up] Instância ${inst} = ${num}`);
    }
  }
  
  const multiInstanceMode = Object.keys(instanceNumbers).length >= 2;
  
  if (multiInstanceMode) {
    console.log(`[Warm-up] 🔥 MODO MULTI-INSTÂNCIA ATIVADO! ${Object.keys(instanceNumbers).length} chips se aquecerão entre si.`);
  } else {
    console.log(`[Warm-up] MODO SINGLE - Apenas 1 instância disponível`);
  }
  
  const stages = [
    { name: 'initial', days: 1, messagesPerDay: 10, minDelay: 60000, maxDelay: 180000 },
    { name: 'building', days: 2, messagesPerDay: 20, minDelay: 45000, maxDelay: 120000 },
    { name: 'active', days: 2, messagesPerDay: 35, minDelay: 30000, maxDelay: 90000 },
    { name: 'mature', days: 2, messagesPerDay: 50, minDelay: 20000, maxDelay: 60000 }
  ];
  
  let totalMessagesSent = 0;
  let totalMessagesReceived = 0;
  
  for (const stage of stages) {
    console.log(`[Warm-up] Sessão ${sessionId} - Estágio: ${stage.name}`);
    db.run("UPDATE warmup_sessions SET stage = ? WHERE id = ?", [stage.name, sessionId]);
    
    for (let day = 0; day < stage.days; day++) {
      console.log(`[Warm-up] Dia ${day + 1} do estágio ${stage.name} - ${stage.messagesPerDay} mensagens`);
      
      for (let msgCount = 0; msgCount < stage.messagesPerDay; msgCount++) {
        const sessionStatus = await new Promise((resolve) => {
          db.get("SELECT status FROM warmup_sessions WHERE id = ?", [sessionId], (err, row) => resolve(row?.status));
        });
        
        if (sessionStatus === 'paused') {
          await new Promise(r => setTimeout(r, 10000));
          msgCount--;
          continue;
        }
        
        if (sessionStatus === 'stopped') {
          console.log(`[Warm-up] Sessão ${sessionId} parada`);
          return;
        }
        
        let fromInstance, toInstance, toNumber;
        
        if (multiInstanceMode) {
          const availableInstances = Object.keys(instanceNumbers);
          fromInstance = availableInstances[Math.floor(Math.random() * availableInstances.length)];
          const otherInstances = availableInstances.filter(i => i !== fromInstance);
          toInstance = otherInstances[Math.floor(Math.random() * otherInstances.length)];
          toNumber = instanceNumbers[toInstance];
        } else {
          fromInstance = primaryInstance;
          const buddies = config.buddyNumbers || [];
          if (buddies.length === 0) {
            await new Promise(r => setTimeout(r, 60000));
            continue;
          }
          toNumber = buddies[Math.floor(Math.random() * buddies.length)];
        }
        
        const message = WARMUP_MESSAGES.outgoing[Math.floor(Math.random() * WARMUP_MESSAGES.outgoing.length)];
        console.log(`[Warm-up] ${fromInstance} → ${multiInstanceMode ? toInstance : toNumber}: "${message}"`);
        
        const result = await sendWarmupMessage(fromInstance, toNumber, message);
        
        if (result.success) {
          totalMessagesSent++;
          db.run("UPDATE warmup_sessions SET messages_sent = ? WHERE id = ?", [totalMessagesSent, sessionId]);
          db.run(
            "INSERT INTO warmup_logs (session_id, action, details) VALUES (?, ?, ?)",
            [sessionId, 'sent', `De: ${fromInstance}, Para: ${multiInstanceMode ? toInstance : toNumber}, Msg: ${message}`]
          );
          
          if (multiInstanceMode) {
            const replyChance = stage.name === 'initial' ? 0.9 : stage.name === 'building' ? 0.8 : 0.7;
            
            if (Math.random() < replyChance) {
              const replyDelay = 15000 + Math.random() * 45000;
              await new Promise(r => setTimeout(r, replyDelay));
              
              const replyMessage = WARMUP_MESSAGES.incoming[Math.floor(Math.random() * WARMUP_MESSAGES.incoming.length)];
              const fromNumber = instanceNumbers[fromInstance];
              
              console.log(`[Warm-up] ${toInstance} → ${fromInstance}: "${replyMessage}"`);
              
              const replyResult = await sendWarmupMessage(toInstance, fromNumber, replyMessage);
              
              if (replyResult.success) {
                totalMessagesReceived++;
                db.run("UPDATE warmup_sessions SET messages_received = ? WHERE id = ?", [totalMessagesReceived, sessionId]);
                db.run(
                  "INSERT INTO warmup_logs (session_id, action, details) VALUES (?, ?, ?)",
                  [sessionId, 'received', `De: ${toInstance}, Para: ${fromInstance}, Msg: ${replyMessage}`]
                );
                
                if (Math.random() < 0.4) {
                  await new Promise(r => setTimeout(r, 10000 + Math.random() * 20000));
                  const followUp = WARMUP_MESSAGES.outgoing[Math.floor(Math.random() * WARMUP_MESSAGES.outgoing.length)];
                  await sendWarmupMessage(fromInstance, toNumber, followUp);
                  totalMessagesSent++;
                  db.run("UPDATE warmup_sessions SET messages_sent = ? WHERE id = ?", [totalMessagesSent, sessionId]);
                }
              }
            }
          } else {
            if (Math.random() < 0.8) {
              await new Promise(r => setTimeout(r, 10000 + Math.random() * 50000));
              totalMessagesReceived++;
              db.run("UPDATE warmup_sessions SET messages_received = ? WHERE id = ?", [totalMessagesReceived, sessionId]);
            }
          }
          
          const currentScore = Math.min(Math.round((totalMessagesSent / 200) * 100), 100);
          const progress = Math.round((totalMessagesSent / 200) * 100);
          db.run("UPDATE warmup_sessions SET current_score = ?, progress = ? WHERE id = ?", [currentScore, progress, sessionId]);
        }
        
        const delay = stage.minDelay + Math.random() * (stage.maxDelay - stage.minDelay);
        await new Promise(r => setTimeout(r, delay));
      }
      
      await new Promise(r => setTimeout(r, 10000));
    }
  }
  
  db.run(
    "UPDATE warmup_sessions SET status = 'completed', completed_at = datetime('now'), current_score = 100, progress = 100 WHERE id = ?",
    [sessionId]
  );
  
  console.log(`[Warm-up] ✅ Sessão ${sessionId} COMPLETADA! ${totalMessagesSent} enviadas, ${totalMessagesReceived} recebidas`);
}

// ========== STATS ==========

app.get('/api/stats', (req, res) => {
  db.get("SELECT COUNT(*) as total FROM campaigns", (err, campaigns) => {
    db.get("SELECT COUNT(*) as total FROM contacts", (err, contacts) => {
      db.get(`
        SELECT SUM(sent_count) as total_sent,
          SUM(delivered_count) as total_delivered,
          SUM(read_count) as total_read,
          SUM(replied_count) as total_replied
        FROM campaigns
      `, (err, stats) => {
        res.json({
          totalCampaigns: campaigns?.total || 0,
          totalContacts: contacts?.total || 0,
          today: {
            sent: stats?.total_sent || 0,
            delivered: stats?.total_delivered || 0,
            read: stats?.total_read || 0,
            replied: stats?.total_replied || 0
          },
          conversionRates: {
            delivery: stats?.total_sent ? Math.round((stats.total_delivered / stats.total_sent) * 100) : 0,
            read: stats?.total_delivered ? Math.round((stats.total_read / stats.total_delivered) * 100) : 0,
            reply: stats?.total_read ? Math.round((stats.total_replied / stats.total_read) * 100) : 0
          }
        });
      });
    });
  });
});

app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    service: 'Agency Marketing API',
    version: '5.0-multi-instance'
  });
});

app.get('/', (req, res) => {
  res.json({
    name: 'Agency Marketing API',
    version: '5.0',
    features: ['Evolution API integration', 'Campaign management', 'Templates', 'Mailing lists', 'Multi-instance Warm-up']
  });
});

initDB();

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Agency API v5.0 (Multi-Instance Warm-up) rodando na porta ${PORT}`);
});
