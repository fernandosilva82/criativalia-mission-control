const Database = require('better-sqlite3');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

require('dotenv').config();

// Config
const CONFIG = {
  apiUrl: process.env.EVOLUTION_API_URL || 'http://localhost:8080',
  apiKey: process.env.EVOLUTION_API_KEY,
  rotationMode: process.env.ROTATION_MODE || 'round-robin',
  messagesPerInstance: parseInt(process.env.MESSAGES_PER_INSTANCE) || 100,
  cooldownBetweenInstances: parseInt(process.env.COOLDOWN_BETWEEN_INSTANCES) || 5,
  delayMin: parseInt(process.env.DELAY_MIN_MS) || 3000,
  delayMax: parseInt(process.env.DELAY_MAX_MS) || 8000,
  dailyLimit: parseInt(process.env.DAILY_LIMIT_PER_INSTANCE) || 200
};

// Database
const dbPath = process.env.DB_PATH || './data/rotator.db';
if (!fs.existsSync(path.dirname(dbPath))) {
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
}

const db = new Database(dbPath);

// Init DB
db.exec(`
  CREATE TABLE IF NOT EXISTS instances (
    id TEXT PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    status TEXT DEFAULT 'disconnected',
    phone TEXT,
    connected_at DATETIME,
    last_used DATETIME,
    messages_sent_today INTEGER DEFAULT 0,
    messages_sent_total INTEGER DEFAULT 0,
    last_reset_date DATE,
    priority INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS mailing (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    phone TEXT NOT NULL,
    name TEXT,
    status TEXT DEFAULT 'pending',
    instance_id TEXT,
    sent_at DATETIME,
    error TEXT,
    retry_count INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    level TEXT,
    instance_name TEXT,
    phone TEXT,
    message TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE INDEX IF NOT EXISTS idx_mailing_status ON mailing(status);
  CREATE INDEX IF NOT EXISTS idx_mailing_instance ON mailing(instance_id);
`);

// Logger
function log(level, message, meta = {}) {
  const timestamp = new Date().toISOString();
  console.log(`[${timestamp}] [${level.toUpperCase()}]`, message, meta);
  
  const stmt = db.prepare('INSERT INTO logs (level, instance_name, phone, message) VALUES (?, ?, ?, ?)');
  stmt.run(level, meta.instance || '', meta.phone || '', message);
}

// Evolution API Client
class EvolutionAPI {
  async request(method, endpoint, data = null, instanceName = null) {
    const url = `${CONFIG.apiUrl}${endpoint}`;
    const headers = {
      'Content-Type': 'application/json',
      'apikey': CONFIG.apiKey
    };
    
    if (instanceName) {
      headers.instance = instanceName;
    }

    try {
      const response = await axios({ method, url, data, headers, timeout: 30000 });
      return { success: true, data: response.data };
    } catch (error) {
      return { 
        success: false, 
        error: error.response?.data?.message || error.message 
      };
    }
  }

  async createInstance(name) {
    return this.request('POST', '/instance/create', { instanceName: name });
  }

  async connectInstance(name) {
    return this.request('GET', `/instance/connect/${name}`);
  }

  async fetchInstances() {
    return this.request('GET', '/instance/fetchInstances');
  }

  async deleteInstance(name) {
    return this.request('DELETE', `/instance/delete/${name}`);
  }

  async sendText(instance, number, text) {
    const cleanNumber = number.replace(/\D/g, '');
    return this.request('POST', '/message/sendText', {
      number: cleanNumber,
      text
    }, instance);
  }

  async getInstanceStatus(name) {
    const result = await this.request('POST', '/instance/connectionState', {}, name);
    return result;
  }
}

const evolution = new EvolutionAPI();

// Instance Manager
class InstanceManager {
  // Adicionar instância ao banco
  addInstance(name) {
    try {
      const stmt = db.prepare('INSERT OR IGNORE INTO instances (id, name) VALUES (?, ?)');
      stmt.run(name, name);
      log('info', `Instância ${name} adicionada ao gerenciador`);
      return true;
    } catch (error) {
      log('error', `Erro ao adicionar instância: ${error.message}`);
      return false;
    }
  }

  // Listar todas as instâncias
  listInstances() {
    return db.prepare('SELECT * FROM instances ORDER BY priority DESC, name').all();
  }

  // Listar instâncias ativas e conectadas
  getActiveInstances() {
    const today = new Date().toISOString().split('T')[0];
    
    return db.prepare(`
      SELECT * FROM instances 
      WHERE is_active = 1 
        AND status = 'connected'
        AND (last_reset_date IS NULL OR last_reset_date < ?)
        AND messages_sent_today < ?
      ORDER BY messages_sent_today ASC, last_used ASC
    `).all(today, CONFIG.dailyLimit);
  }

  // Atualizar status da instância
  updateStatus(name, status, phone = null) {
    const stmt = db.prepare(`
      UPDATE instances 
      SET status = ?, phone = ?, connected_at = ?
      WHERE name = ?
    `);
    stmt.run(status, phone, new Date().toISOString(), name);
  }

  // Incrementar contador de mensagens
  incrementMessageCount(name) {
    const today = new Date().toISOString().split('T')[0];
    
    // Verificar se precisa resetar
    const instance = db.prepare('SELECT last_reset_date FROM instances WHERE name = ?').get(name);
    
    if (instance?.last_reset_date !== today) {
      // Reset diário
      db.prepare(`
        UPDATE instances 
        SET messages_sent_today = 1, messages_sent_total = messages_sent_total + 1, last_reset_date = ?, last_used = ?
        WHERE name = ?
      `).run(today, new Date().toISOString(), name);
    } else {
      // Incrementar
      db.prepare(`
        UPDATE instances 
        SET messages_sent_today = messages_sent_today + 1, messages_sent_total = messages_sent_total + 1, last_used = ?
        WHERE name = ?
      `).run(new Date().toISOString(), name);
    }
  }

  // Resetar contadores diários
  resetDailyCounters() {
    const today = new Date().toISOString().split('T')[0];
    db.prepare('UPDATE instances SET messages_sent_today = 0, last_reset_date = ?').run(today);
    log('info', 'Contadores diários resetados');
  }

  // Remover instância
  removeInstance(name) {
    db.prepare('DELETE FROM instances WHERE name = ?').run(name);
    log('info', `Instância ${name} removida`);
  }
}

// Rotator
class Rotator {
  constructor() {
    this.instanceManager = new InstanceManager();
    this.currentInstanceIndex = 0;
    this.messagesInCurrentInstance = 0;
    this.lastRotation = Date.now();
  }

  // Selecionar próxima instância
  async selectInstance() {
    const instances = this.instanceManager.getActiveInstances();
    
    if (instances.length === 0) {
      log('error', 'Nenhuma instância ativa disponível');
      return null;
    }

    // Verificar cooldown
    const cooldownMs = CONFIG.cooldownBetweenInstances * 60 * 1000;
    if (Date.now() - this.lastRotation < cooldownMs) {
      // Manter instância atual se dentro do cooldown
      const current = instances[this.currentInstanceIndex % instances.length];
      if (current && current.messages_sent_today < CONFIG.messagesPerInstance) {
        return current;
      }
    }

    // Selecionar baseado no modo
    let selected;
    
    switch (CONFIG.rotationMode) {
      case 'round-robin':
        selected = instances[this.currentInstanceIndex % instances.length];
        this.currentInstanceIndex++;
        break;
        
      case 'least-used':
        selected = instances[0]; // Já ordenado por messages_sent_today
        break;
        
      case 'random':
        selected = instances[Math.floor(Math.random() * instances.length)];
        break;
        
      default:
        selected = instances[0];
    }

    // Verificar se atingiu limite por instância
    if (selected.messages_sent_today >= CONFIG.messagesPerInstance) {
      // Tentar próxima
      const nextIndex = (this.currentInstanceIndex + 1) % instances.length;
      selected = instances[nextIndex];
      
      if (!selected || selected.messages_sent_today >= CONFIG.messagesPerInstance) {
        log('warn', 'Todas as instâncias atingiram limite, aguardando...');
        return null;
      }
    }

    this.lastRotation = Date.now();
    log('info', `Instância selecionada: ${selected.name} (${selected.messages_sent_today}/${CONFIG.dailyLimit} msgs)`);
    
    return selected;
  }

  // Enviar mensagem com rotação
  async sendMessage(phone, message) {
    const instance = await this.selectInstance();
    
    if (!instance) {
      return { success: false, error: 'Nenhuma instância disponível' };
    }

    // Delay aleatório
    const delay = Math.floor(Math.random() * (CONFIG.delayMax - CONFIG.delayMin + 1)) + CONFIG.delayMin;
    await new Promise(r => setTimeout(r, delay));

    // Enviar
    const result = await evolution.sendText(instance.name, phone, message);
    
    if (result.success) {
      this.instanceManager.incrementMessageCount(instance.name);
      log('info', `Mensagem enviada via ${instance.name}`, { instance: instance.name, phone });
    } else {
      log('error', `Falha ao enviar via ${instance.name}: ${result.error}`, { instance: instance.name, phone });
    }

    return result;
  }
}

// Mailing Processor
class MailingProcessor {
  constructor() {
    this.rotator = new Rotator();
    this.isRunning = false;
    this.paused = false;
  }

  // Carregar mailing do CSV
  loadFromCSV(filePath) {
    const content = fs.readFileSync(filePath, 'utf8');
    const lines = content.split('\n').filter(line => line.trim());
    
    const stmt = db.prepare('INSERT INTO mailing (phone, name) VALUES (?, ?)');
    const insertMany = db.transaction((contacts) => {
      for (const contact of contacts) {
        stmt.run(contact.phone, contact.name || '');
      }
    });

    const contacts = lines.map(line => {
      const parts = line.split(',').map(p => p.trim());
      return { phone: parts[0], name: parts[1] || '' };
    }).filter(c => c.phone && c.phone.match(/^\d{10,15}$/));

    insertMany(contacts);
    
    log('info', `${contacts.length} contatos carregados do mailing`);
    return contacts.length;
  }

  // Processar mailing
  async process(messageTemplate, onProgress = null) {
    if (this.isRunning) {
      log('warn', 'Processamento já em andamento');
      return;
    }

    this.isRunning = true;
    
    const pending = db.prepare(`
      SELECT * FROM mailing 
      WHERE status = 'pending' AND retry_count < 3
      ORDER BY id
    `).all();

    log('info', `Iniciando processamento de ${pending.length} contatos`);

    let sent = 0;
    let failed = 0;
    let skipped = 0;

    for (let i = 0; i < pending.length; i++) {
      if (this.paused) {
        log('info', 'Processamento pausado');
        break;
      }

      const contact = pending[i];
      
      // Verificar se já foi enviado hoje
      const today = new Date().toISOString().split('T')[0];
      const alreadySent = db.prepare(`
        SELECT COUNT(*) as count FROM mailing 
        WHERE phone = ? AND status = 'sent' AND DATE(sent_at) = ?
      `).get(contact.phone, today);
      
      if (alreadySent.count > 0) {
        skipped++;
        continue;
      }

      // Personalizar mensagem
      const message = messageTemplate
        .replace(/{nome}/gi, contact.name || 'Cliente')
        .replace(/{telefone}/gi, contact.phone);

      // Enviar com rotação
      const result = await this.rotator.sendMessage(contact.phone, message);

      if (result.success) {
        db.prepare(`
          UPDATE mailing SET status = 'sent', sent_at = ?, instance_id = ? WHERE id = ?
        `).run(new Date().toISOString(), 'rotated', contact.id);
        sent++;
      } else {
        db.prepare(`
          UPDATE mailing SET status = 'failed', error = ?, retry_count = retry_count + 1 WHERE id = ?
        `).run(result.error.substring(0, 255), contact.id);
        failed++;
      }

      // Progress callback
      if (onProgress) {
        onProgress({
          current: i + 1,
          total: pending.length,
          sent,
          failed,
          skipped,
          percentage: Math.round(((i + 1) / pending.length) * 100)
        });
      }

      // Log a cada 10 mensagens
      if ((i + 1) % 10 === 0) {
        log('info', `Progresso: ${i + 1}/${pending.length} (${sent} enviadas, ${failed} falhas)`);
      }
    }

    this.isRunning = false;
    
    log('info', 'Processamento finalizado', { sent, failed, skipped });
    
    return { sent, failed, skipped, total: pending.length };
  }

  pause() {
    this.paused = true;
  }

  resume() {
    this.paused = false;
    if (!this.isRunning) {
      this.process();
    }
  }

  getStats() {
    const stats = db.prepare(`
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) as sent,
        SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending
      FROM mailing
    `).get();

    return stats;
  }

  reset() {
    db.prepare("UPDATE mailing SET status = 'pending', sent_at = NULL, error = NULL, retry_count = 0").run();
    log('info', 'Mailing resetado');
  }
}

// Exportar módulos
module.exports = {
  EvolutionAPI,
  InstanceManager,
  Rotator,
  MailingProcessor,
  db,
  log,
  CONFIG
};
