#!/usr/bin/env node
/**
 * WhatsApp Rotator CLI
 * Interface de linha de comando para gerenciar múltiplas instâncias
 */

const { 
  EvolutionAPI, 
  InstanceManager, 
  MailingProcessor, 
  log,
  db 
} = require('./core');
const readline = require('readline');
const fs = require('fs');
const path = require('path');

const evolution = new EvolutionAPI();
const instanceManager = new InstanceManager();
const processor = new MailingProcessor();

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function question(prompt) {
  return new Promise(resolve => rl.question(prompt, resolve));
}

// Menu principal
async function showMenu() {
  console.clear();
  console.log(`
╔══════════════════════════════════════════════════════════════╗
║           📱 WHATSAPP ROTATOR - Centro de Comando           ║
╚══════════════════════════════════════════════════════════════╝

[1] 🆕  Criar nova instância
[2] 🔗  Conectar instância (QR Code)
[3] 📋  Listar instâncias
[4] 🗑️  Remover instância
[5] 📊  Status das instâncias

[6] 📁  Carregar mailing (CSV)
[7] 🚀  Iniciar disparo
[8] ⏸️  Pausar/Retomar
[9] 📈  Estatísticas do mailing
[10] 🔄 Resetar mailing

[11] 📜  Ver logs
[0]  ❌  Sair
`);

  const choice = await question('Escolha uma opção: ');
  
  switch(choice.trim()) {
    case '1': await createInstance(); break;
    case '2': await connectInstance(); break;
    case '3': await listInstances(); break;
    case '4': await removeInstance(); break;
    case '5': await checkStatus(); break;
    case '6': await loadMailing(); break;
    case '7': await startMailing(); break;
    case '8': await togglePause(); break;
    case '9': await showStats(); break;
    case '10': await resetMailing(); break;
    case '11': await showLogs(); break;
    case '0': process.exit(0);
    default: console.log('Opção inválida');
  }
  
  await question('\nPressione ENTER para continuar...');
  showMenu();
}

// Criar instância
async function createInstance() {
  const name = await question('Nome da instância (ex: negocio-01): ');
  if (!name) return;

  console.log(`\n🔄 Criando instância ${name}...`);
  
  const result = await evolution.createInstance(name);
  
  if (result.success) {
    instanceManager.addInstance(name);
    console.log(`✅ Instância ${name} criada com sucesso!`);
    console.log(`📱 Agora escolha opção 2 para conectar`);
  } else {
    console.log(`❌ Erro: ${result.error}`);
  }
}

// Conectar instância
async function connectInstance() {
  const instances = instanceManager.listInstances();
  
  if (instances.length === 0) {
    console.log('❌ Nenhuma instância cadastrada');
    return;
  }

  console.log('\n📋 Instâncias disponíveis:');
  instances.forEach((inst, i) => {
    console.log(`  [${i + 1}] ${inst.name} (${inst.status})`);
  });

  const choice = await question('\nEscolha o número: ');
  const instance = instances[parseInt(choice) - 1];
  
  if (!instance) {
    console.log('❌ Instância inválida');
    return;
  }

  console.log(`\n🔄 Gerando QR Code para ${instance.name}...`);
  console.log('⏳ Aguarde...\n');
  
  const result = await evolution.connectInstance(instance.name);
  
  if (result.success && result.data?.base64) {
    // Salvar QR code como imagem
    const qrPath = path.join(__dirname, '..', 'instances', `${instance.name}-qr.png`);
    const base64Data = result.data.base64.replace(/^data:image\/png;base64,/, '');
    fs.writeFileSync(qrPath, base64Data, 'base64');
    
    console.log('✅ QR Code gerado!');
    console.log(`📷 Imagem salva em: ${qrPath}`);
    console.log('\n📱 Abra o WhatsApp no celular → Configurações → Aparelhos Conectados → Conectar');
    console.log('   e escaneie o QR Code\n');
    
    // Aguardar conexão
    console.log('⏳ Aguardando conexão (30s)...');
    await new Promise(r => setTimeout(r, 30000));
    
    // Verificar status
    const status = await evolution.getInstanceStatus(instance.name);
    if (status.success) {
      instanceManager.updateStatus(instance.name, 'connected');
      console.log(`✅ Instância ${instance.name} conectada!`);
    } else {
      console.log(`⚠️  Status: ${status.data?.state || 'desconhecido'}`);
    }
  } else {
    console.log(`❌ Erro ao gerar QR Code: ${result.error}`);
  }
}

// Listar instâncias
async function listInstances() {
  const instances = instanceManager.listInstances();
  
  if (instances.length === 0) {
    console.log('📭 Nenhuma instância cadastrada');
    return;
  }

  console.log('\n📱 Instâncias:');
  console.log('─'.repeat(80));
  console.log(`${'Nome'.padEnd(20)} ${'Status'.padEnd(12)} ${'Número'.padEnd(18)} ${'Hoje'.padEnd(8)} Total`);
  console.log('─'.repeat(80));
  
  instances.forEach(inst => {
    console.log(
      `${inst.name.padEnd(20)} ` +
      `${inst.status.padEnd(12)} ` +
      `${(inst.phone || '-').padEnd(18)} ` +
      `${inst.messages_sent_today.toString().padEnd(8)} ` +
      `${inst.messages_sent_total}`
    );
  });
}

// Remover instância
async function removeInstance() {
  const instances = instanceManager.listInstances();
  
  if (instances.length === 0) {
    console.log('❌ Nenhuma instância');
    return;
  }

  await listInstances();
  const name = await question('\nNome da instância para remover: ');
  
  if (!name) return;
  
  const confirm = await question(`Tem certeza que deseja remover ${name}? (s/n): `);
  if (confirm.toLowerCase() !== 's') return;

  console.log(`🔄 Removendo ${name}...`);
  await evolution.deleteInstance(name);
  instanceManager.removeInstance(name);
  console.log(`✅ Instância ${name} removida`);
}

// Check status
async function checkStatus() {
  console.log('\n🔄 Verificando status das instâncias...\n');
  
  const instances = instanceManager.listInstances();
  
  for (const inst of instances) {
    const result = await evolution.getInstanceStatus(inst.name);
    const status = result.success ? result.data?.state : 'error';
    
    instanceManager.updateStatus(inst.name, status);
    console.log(`  ${inst.name}: ${status}`);
  }
  
  console.log('\n✅ Status atualizado');
}

// Carregar mailing
async function loadMailing() {
  const filePath = await question('Caminho do arquivo CSV: ');
  
  if (!fs.existsSync(filePath)) {
    console.log(`❌ Arquivo não encontrado: ${filePath}`);
    return;
  }

  console.log(`\n🔄 Carregando mailing...`);
  const count = processor.loadFromCSV(filePath);
  console.log(`✅ ${count} contatos carregados`);
}

// Iniciar disparo
async function startMailing() {
  const stats = processor.getStats();
  
  if (stats.pending === 0) {
    console.log('❌ Nenhum contato pendente. Carregue um mailing primeiro (opção 6)');
    return;
  }

  console.log(`\n📊 Status atual: ${stats.sent} enviadas, ${stats.pending} pendentes, ${stats.failed} falhas`);
  
  const message = await question('\nMensagem (use {nome} e {telefone} para personalizar): \n');
  
  if (!message) {
    console.log('❌ Mensagem vazia');
    return;
  }

  console.log('\n🚀 Iniciando disparo...\n');
  console.log('Pressione CTRL+C para parar\n');

  // Progress bar
  const progressBar = (progress) => {
    const width = 40;
    const filled = Math.round((progress.percentage / 100) * width);
    const bar = '█'.repeat(filled) + '░'.repeat(width - filled);
    process.stdout.write(`\r${bar} ${progress.percentage}% | ${progress.current}/${progress.total} | ✓${progress.sent} ✗${progress.failed}`);
  };

  const result = await processor.process(message, progressBar);
  
  console.log('\n\n✅ Disparo finalizado!');
  console.log(`   Enviadas: ${result.sent}`);
  console.log(`   Falhas: ${result.failed}`);
  console.log(`   Puladas: ${result.skipped}`);
}

// Toggle pause
async function togglePause() {
  if (processor.isRunning) {
    processor.pause();
    console.log('⏸️  Disparo pausado');
  } else {
    processor.resume();
    console.log('▶️  Disparo retomado');
  }
}

// Show stats
async function showStats() {
  const stats = processor.getStats();
  const instances = instanceManager.listInstances();
  
  console.log('\n╔════════════════════════════════════════╗');
  console.log('║           📊 ESTATÍSTICAS              ║');
  console.log('╚════════════════════════════════════════╝\n');
  
  console.log('📧 Mailing:');
  console.log(`   Total: ${stats.total}`);
  console.log(`   ✅ Enviadas: ${stats.sent}`);
  console.log(`   ⏳ Pendentes: ${stats.pending}`);
  console.log(`   ❌ Falhas: ${stats.failed}`);
  console.log(`   Taxa: ${stats.total > 0 ? Math.round((stats.sent / stats.total) * 100) : 0}%\n`);
  
  console.log('📱 Instâncias:');
  instances.forEach(inst => {
    console.log(`   ${inst.name}: ${inst.messages_sent_today} msgs hoje (${inst.status})`);
  });
}

// Reset mailing
async function resetMailing() {
  const confirm = await question('⚠️  Isso resetará todo o mailing. Continuar? (s/n): ');
  if (confirm.toLowerCase() === 's') {
    processor.reset();
    console.log('✅ Mailing resetado');
  }
}

// Show logs
async function showLogs() {
  const logs = db.prepare('SELECT * FROM logs ORDER BY created_at DESC LIMIT 20').all();
  
  console.log('\n📜 Últimos logs:\n');
  logs.reverse().forEach(log => {
    const time = new Date(log.created_at).toLocaleTimeString();
    console.log(`[${time}] [${log.level.toUpperCase()}] ${log.message}`);
  });
}

// Start
console.log('Iniciando WhatsApp Rotator...\n');
showMenu();
