#!/bin/bash

# Script para fazer push do WhatsApp Rotator para o GitHub
# Execute na sua máquina local

echo "🚀 Fazendo push do WhatsApp Rotator para GitHub"
echo ""

# Verificar se existe repositório
if [ ! -d ".git" ]; then
    echo "❌ Diretório .git não encontrado. Execute do diretório whatsapp-rotator."
    exit 1
fi

# Configurar remote (se não existir)
git remote get-url origin > /dev/null 2>&1 || {
    echo "🔧 Configurando remote..."
    git remote add origin https://github.com/fernandosilva82/whatsapp-rotator.git
}

# Verificar branch atual
CURRENT_BRANCH=$(git branch --show-current)
echo "📍 Branch atual: $CURRENT_BRANCH"

# Push para GitHub
echo ""
echo "📤 Enviando código para GitHub..."
git push -u origin $CURRENT_BRANCH

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Sucesso! Código enviado para:"
    echo "   https://github.com/fernandosilva82/whatsapp-rotator"
    echo ""
    echo "🚀 Próximo passo - Deploy no Render:"
    echo "   1. Acesse: https://dashboard.render.com/blueprint"
    echo "   2. Cole esta URL: https://github.com/fernandosilva82/whatsapp-rotator"
    echo "   3. Clique 'Apply Blueprint'"
    echo ""
else
    echo ""
    echo "❌ Push falhou. Possíveis causas:"
    echo "   1. Repositório não existe no GitHub ainda"
    echo "   2. Credenciais não configuradas"
    echo ""
    echo "📋 Solução:"
    echo "   1. Crie o repositório em: https://github.com/new"
    echo "      Nome: whatsapp-rotator"
    echo "      Público ou privado (sua escolha)"
    echo "   2. NÃO inicialize com README (já temos)"
    echo "   3. Execute este script novamente"
    echo ""
fi
