const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const WebSocket = require('ws');
const http = require('http');
const { parse } = require('csv-parse/sync');

// Import core modules
const { 
  EvolutionAPI, 
  InstanceManager, 
  Rotator, 
  MailingProcessor, 
  db,
  log,
  CONFIG 
} = require('./src/core');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: '/ws' });

const PORT = process.env.PORT || 3333;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// Upload config
const upload = multer({ dest: '/tmp/uploads/' });

// Instances
const evolution = new EvolutionAPI();
const instanceManager = new InstanceManager();
const rotator = new Rotator();
const processor = new MailingProcessor();

// Broadcast to all WebSocket clients
function broadcast(data) {
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify(data));
    }
  });
}

// Override log to broadcast
const originalLog = log;
log = function(level, message, meta = {}) {
  originalLog(level, message, meta);
  broadcast({ type: 'log', level, message, meta, timestamp: new Date().toISOString() });
};

// ===== API ROUTES =====

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    version: '1.0.0'
  });
});

// Dashboard stats
app.get('/api/stats', (req, res) => {
  const instances = db.prepare('SELECT COUNT(*) as total, SUM(messages_sent_today) as sent FROM instances').get();
  const mailing = db.prepare(`
    SELECT 
      COUNT(*) as total,
      SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) as sent,
      SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
      SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed
    FROM mailing
  `).get();
  
  const activeInstances = db.prepare("SELECT COUNT(*) as count FROM instances WHERE status = 'connected'").get();
  
  res.json({
    instances: {
      total: instances.total,
      active: activeInstances.count,
      sentToday: instances.sent || 0
    },
    mailing: {
      total: mailing.total,
      sent: mailing.sent || 0,
      pending: mailing.pending || 0,
      failed: mailing.failed || 0,
      progress: mailing.total > 0 ? Math.round((mailing.sent / mailing.total) * 100) : 0
    }
  });
});

// Get all instances
app.get('/api/instances', (req, res) => {
  const instances = instanceManager.listInstances();
  res.json(instances);
});

// Create instance
app.post('/api/instances', async (req, res) => {
  const { name } = req.body;
  
  if (!name) {
    return res.status(400).json({ error: 'Nome é obrigatório' });
  }
  
  const result = await evolution.createInstance(name);
  
  if (result.success) {
    instanceManager.addInstance(name);
    log('info', `Instância ${name} criada`, { instance: name });
    res.json({ success: true, name });
  } else {
    res.status(400).json({ error: result.error });
  }
});

// Connect instance (get QR)
app.get('/api/instances/:name/connect', async (req, res) => {
  const { name } = req.params;
  
  const result = await evolution.connectInstance(name);
  
  if (result.success && result.data?.base64) {
    // Save QR code
    const qrPath = path.join(__dirname, 'instances', `${name}-qr.png`);
    const base64Data = result.data.base64.replace(/^data:image\/png;base64,/, '');
    fs.writeFileSync(qrPath, base64Data, 'base64');
    
    res.json({ 
      success: true, 
      qrCode: result.data.base64,
      qrPath: `/instances/${name}-qr.png`
    });
  } else {
    res.status(400).json({ error: result.error || 'Erro ao gerar QR Code' });
  }
});

// Check instance status
app.get('/api/instances/:name/status', async (req, res) => {
  const { name } = req.params;
  const result = await evolution.getInstanceStatus(name);
  
  if (result.success) {
    instanceManager.updateStatus(name, result.data?.state || 'unknown');
    res.json({ success: true, status: result.data });
  } else {
    res.status(400).json({ error: result.error });
  }
});

// Delete instance
app.delete('/api/instances/:name', async (req, res) => {
  const { name } = req.params;
  
  await evolution.deleteInstance(name);
  instanceManager.removeInstance(name);
  
  // Remove QR file
  const qrPath = path.join(__dirname, 'instances', `${name}-qr.png`);
  if (fs.existsSync(qrPath)) fs.unlinkSync(qrPath);
  
  log('info', `Instância ${name} removida`, { instance: name });
  res.json({ success: true });
});

// Upload CSV
app.post('/api/mailing/upload', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'Arquivo não enviado' });
  }
  
  try {
    const content = fs.readFileSync(req.file.path, 'utf8');
    const records = parse(content, {
      columns: true,
      skip_empty_lines: true
    });
    
    const contacts = records.map(r => ({
      phone: r.telefone || r.phone || r.numero || Object.values(r)[0],
      name: r.nome || r.name || Object.values(r)[1] || ''
    })).filter(c => c.phone && c.phone.match(/^\d{10,15}$/));
    
    // Clear existing and insert new
    db.prepare('DELETE FROM mailing').run();
    const stmt = db.prepare('INSERT INTO mailing (phone, name) VALUES (?, ?)');
    const insertMany = db.transaction((contacts) => {
      for (const contact of contacts) {
        stmt.run(contact.phone, contact.name);
      }
    });
    insertMany(contacts);
    
    fs.unlinkSync(req.file.path);
    
    log('info', `${contacts.length} contatos carregados`, { count: contacts.length });
    res.json({ success: true, count: contacts.length });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Get mailing stats
app.get('/api/mailing/stats', (req, res) => {
  const stats = db.prepare(`
    SELECT 
      COUNT(*) as total,
      SUM(CASE WHEN status = 'sent' THEN 1 ELSE 0 END) as sent,
      SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
      SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed
    FROM mailing
  `).get();
  
  res.json(stats);
});

// Get mailing list (paginated)
app.get('/api/mailing', (req, res) => {
  const limit = parseInt(req.query.limit) || 50;
  const offset = parseInt(req.query.offset) || 0;
  const status = req.query.status;
  
  let query = 'SELECT * FROM mailing';
  let countQuery = 'SELECT COUNT(*) as count FROM mailing';
  const params = [];
  
  if (status) {
    query += ' WHERE status = ?';
    countQuery += ' WHERE status = ?';
    params.push(status);
  }
  
  query += ' ORDER BY id LIMIT ? OFFSET ?';
  
  const contacts = db.prepare(query).all(...params, limit, offset);
  const { count } = db.prepare(countQuery).get(...params);
  
  res.json({ contacts, total: count, limit, offset });
});

// Reset mailing
app.post('/api/mailing/reset', (req, res) => {
  db.prepare("UPDATE mailing SET status = 'pending', sent_at = NULL, error = NULL, retry_count = 0").run();
  log('info', 'Mailing resetado');
  res.json({ success: true });
});

// Start sending
app.post('/api/mailing/send', async (req, res) => {
  const { message } = req.body;
  
  if (!message) {
    return res.status(400).json({ error: 'Mensagem é obrigatória' });
  }
  
  // Check if already running
  if (processor.isRunning) {
    return res.status(400).json({ error: 'Envio já em andamento' });
  }
  
  // Start in background
  processor.process(message, (progress) => {
    broadcast({ 
      type: 'progress', 
      ...progress 
    });
  }).then(result => {
    broadcast({ 
      type: 'complete', 
      result 
    });
  });
  
  res.json({ success: true, started: true });
});

// Pause/Resume
app.post('/api/mailing/pause', (req, res) => {
  processor.pause();
  res.json({ paused: true });
});

app.post('/api/mailing/resume', (req, res) => {
  processor.resume();
  res.json({ resumed: true });
});

// Get logs
app.get('/api/logs', (req, res) => {
  const limit = parseInt(req.query.limit) || 100;
  const logs = db.prepare('SELECT * FROM logs ORDER BY created_at DESC LIMIT ?').all(limit);
  res.json(logs);
});

// Send test message
app.post('/api/test-send', async (req, res) => {
  const { instance, number, message } = req.body;
  
  if (!instance || !number || !message) {
    return res.status(400).json({ error: 'Dados incompletos' });
  }
  
  const result = await evolution.sendText(instance, number, message);
  
  if (result.success) {
    instanceManager.incrementMessageCount(instance);
    log('info', 'Mensagem de teste enviada', { instance, number });
  }
  
  res.json(result);
});

// Serve QR codes
app.use('/instances', express.static(path.join(__dirname, 'instances')));

// Serve frontend
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// WebSocket
wss.on('connection', (ws) => {
  log('info', 'Cliente WebSocket conectado');
  
  ws.on('close', () => {
    log('info', 'Cliente WebSocket desconectado');
  });
});

// Start server
server.listen(PORT, () => {
  console.log(`🚀 WhatsApp Rotator Web rodando na porta ${PORT}`);
  console.log(`📱 Acesse: http://localhost:${PORT}`);
});
