#!/bin/bash
# WhatsApp Rotator - Setup

echo "📱 WhatsApp Rotator - Setup"
echo "============================"
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js não encontrado"
    echo "Instale: https://nodejs.org/"
    exit 1
fi

echo "✓ Node.js $(node --version)"

# Create directories
mkdir -p data instances

# Install dependencies
echo ""
echo "📦 Instalando dependências..."
npm install

# Setup .env
if [ ! -f ".env" ]; then
    echo ""
    echo "📝 Criando .env..."
    cp .env.example .env
    
    # Generate random key
    API_KEY=$(date +%s | sha256sum | base64 | head -c 32)
    sed -i "s/sua_chave_aqui/$API_KEY/" .env
    
    echo "✓ .env criado"
    echo "⚠️  Edite o arquivo .env e configure:"
    echo "   - EVOLUTION_API_URL (URL da sua Evolution API)"
    echo "   - EVOLUTION_API_KEY (deve bater com a da Evolution)"
else
    echo "✓ .env já existe"
fi

# Create sample mailing
cat > mailing-exemplo.csv << 'EOF'
telefone,nome
5511999999999,Cliente 1
5511888888888,Cliente 2
5511777777777,Cliente 3
5511666666666,Cliente 4
5511555555555,Cliente 5
EOF

echo ""
echo "✓ mailing-exemplo.csv criado"
echo ""
echo "============================"
echo "✅ Setup concluído!"
echo ""
echo "Para iniciar:"
echo "  npm start"
echo ""
echo "Fluxo de uso:"
echo "  1. Crie instâncias (opção 1)"
echo "  2. Conecte com QR Code (opção 2)"
echo "  3. Carregue mailing CSV (opção 6)"
echo "  4. Inicie o disparo (opção 7)"
echo ""
