# 📱 WhatsApp Rotator - Painel Web

Sistema completo de **múltiplas instâncias WhatsApp** com **rotação automática** e interface web para gerenciamento.

## 🎯 Funcionalidades

- ✅ **Painel Web** - Interface moderna e responsiva
- ✅ **Múltiplas Instâncias** - Gerencie N números WhatsApp
- 🔄 **Rotação Automática** - Distribui carga entre instâncias
- 📧 **Mailing CSV** - Upload e gerenciamento de listas
- 📊 **Dashboard** - Estatísticas em tempo real
- 📜 **Logs ao Vivo** - WebSocket para monitoramento
- 🚀 **Disparo em Massa** - Com anti-block integrado

---

## 🚀 Deploy Rápido

```bash
cd whatsapp-rotator
bash deploy.sh
```

Acesse: **http://localhost:3333**

---

## 📸 Screenshots

### Dashboard
```
┌─────────────────────────────────────────────────────────────┐
│  📱 WhatsApp Rotator          [Dashboard] [Instâncias] ...  │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐       │
│  │ 3        │ │ 5,230    │ │ 4,180    │ │ 1,050    │       │
│  │ Instânc. │ │ Total    │ │ Enviadas │ │ Pendentes│       │
│  │ Ativas   │ │ Mailing  │ │          │ │          │       │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘       │
│                                                             │
│  📈 Progresso do Envio                         [Enviando]  │
│  ██████████████████████░░░░░  78%                          │
│                                                             │
│     4,180        1,050        0                             │
│   Enviadas     Pendentes    Falhas                         │
│                                                             │
│  [▶ Iniciar] [⏸ Pausar]                                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Instâncias
```
┌─────────────────────────────────────────────────────────────┐
│  Instâncias WhatsApp                    [➕ Nova Instância]  │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Nome          Status      Número         Hoje    Ações     │
│  ─────────────────────────────────────────────────────────  │
│  negocio-01    🟢 conect. 55119999...     98      [🔗] [🗑️] │
│  negocio-02    🟢 conect. 55118888...     95      [🔗] [🗑️] │
│  negocio-03    ⚪ descon. -               0       [🔗] [🗑️] │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎮 Como Usar

### 1. Subir o Sistema
```bash
cd whatsapp-rotator
bash deploy.sh
```

### 2. Acessar Interface
Abra no navegador: **http://localhost:3333**

### 3. Criar Instâncias
1. Vá em **"Instâncias"**
2. Clique **"Nova Instância"**
3. Digite um nome (ex: `negocio-01`)
4. Clique **"Conectar"** e escaneie o QR Code

### 4. Upload de Mailing
1. Vá em **"Mailing"**
2. Arraste ou selecione um arquivo CSV
3. Formato: `telefone,nome`
```csv
5511999999999,Fernando
5511888888888,Maria
5511777777777,João
```

### 5. Iniciar Disparo
1. Vá em **"Disparo"** ou use o Dashboard
2. Digite a mensagem (use `{nome}` para personalizar)
3. Clique **"Iniciar Disparo"**
4. Acompanhe o progresso em tempo real!

---

## 🔧 Configuração

Edite `.env` para ajustar:

```env
# Rotação
ROTATION_MODE=round-robin       # round-robin | least-used | random
MESSAGES_PER_INSTANCE=100       # Troca após 100 msgs
COOLDOWN_BETWEEN_INSTANCES=5    # Minutos entre trocas

# Anti-Block
DELAY_MIN_MS=5000              # 5s mínimo entre msgs
DELAY_MAX_MS=10000             # 10s máximo
DAILY_LIMIT_PER_INSTANCE=200   # Limite diário
```

---

## 🔄 Como funciona a Rotação

Com 5 instâncias e 1000 contatos:

```
Instância 1 → 100 mensagens → cooldown 5min
Instância 2 → 100 mensagens → cooldown 5min
Instância 3 → 100 mensagens → cooldown 5min
Instância 4 → 100 mensagens → cooldown 5min
Instância 5 → 100 mensagens → cooldown 5min
(25 minutos depois...)
Instância 1 → próximas 100 (já resetou)
...
```

**Resultado:** 1000 mensagens distribuídas em ~4 horas, cada número envia só 100 msgs antes de "descansar".

---

## 📡 API Endpoints

| Endpoint | Descrição |
|----------|-----------|
| `GET /api/stats` | Estatísticas do sistema |
| `GET /api/instances` | Listar instâncias |
| `POST /api/instances` | Criar instância |
| `GET /api/instances/:name/connect` | Gerar QR Code |
| `POST /api/mailing/upload` | Upload CSV |
| `POST /api/mailing/send` | Iniciar disparo |
| `GET /api/logs` | Ver logs |
| `WS /ws` | WebSocket para tempo real |

---

## 🛡️ Anti-Block Automático

- ✅ Delay aleatório: 5-10s entre mensagens
- ✅ Rotação automática de instâncias
- ✅ Cooldown entre trocas
- ✅ Limite diário por número
- ✅ Retry em caso de falha

---

## 🐳 Docker

```bash
# Subir tudo
docker-compose up -d

# Ver logs
docker-compose logs -f rotator

# Parar
docker-compose down
```

---

## 💡 Dicas

1. **Para mailing GRANDE** (10k+): Use 10+ instâncias
2. **Aqueça os números** antes: Envie mensagens manuais por alguns dias
3. **Monitore os logs**: Página "Logs" mostra tudo em tempo real
4. **QR Code não aparece?**: Verifique se a Evolution API está rodando

---

**Pronto para usar!** 🚀 Acesse http://localhost:3333
