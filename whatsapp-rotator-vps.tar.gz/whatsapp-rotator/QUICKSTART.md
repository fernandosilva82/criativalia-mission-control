# Quick Start

## 1. Instalar
```bash
cd whatsapp-rotator
bash setup.sh
```

## 2. Configurar
```bash
nano .env
# Edite:
# - EVOLUTION_API_URL
# - EVOLUTION_API_KEY
```

## 3. Iniciar
```bash
npm start
```

## 4. Criar Instâncias
```
Menu → [1] Criar nova instância
→ Nome: negocio-01

Menu → [2] Conectar instância
→ Escolha negocio-01
→ Escaneie QR Code
```

## 5. Preparar Mailing
```bash
# Formato: telefone,nome
cat > mailing.csv << 'EOF'
5511999999999,Fernando
5511888888888,Maria
5511777777777,João
EOF
```

## 6. Enviar
```
Menu → [6] Carregar mailing
→ Caminho: ./mailing.csv

Menu → [7] Iniciar disparo
→ Mensagem: Olá {nome}! Tudo bem?
```

## 7. Acompanhar
- Veja progresso em tempo real
- Estatísticas (opção 9)
- Logs (opção 11)

## Dicas
- Crie 3-5 instâncias para rotacionar
- Use `{nome}` para personalizar mensagens
- Limite de ~200 mensagens/dia por número
- Delay automático entre mensagens
