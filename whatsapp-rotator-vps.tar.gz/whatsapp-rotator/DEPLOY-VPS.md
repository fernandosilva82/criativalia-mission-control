# WhatsApp Rotator - Deploy VPS Hostinger

## Deploy Rápido (3 comandos)

```bash
# 1. Acesse sua VPS via SSH
ssh root@SEU_IP_DA_VPS

# 2. Baixe o script
curl -O https://raw.githubusercontent.com/fernandosilva82/whatsapp-rotator/main/deploy-vps.sh

# 3. Execute
bash deploy-vps.sh
```

## Acesso

Após o deploy, acesse:
- **Interface Web**: `http://IP_DA_VPS:3333`
- **Evolution API**: `http://IP_DA_VPS:8080`

## Configurar Domínio (Opcional)

Se tiver um domínio, configure o DNS apontando para o IP da VPS e execute:

```bash
bash deploy-vps.sh meudominio.com
```

Depois configure o Nginx:

```bash
apt install nginx -y

# Criar config
cat > /etc/nginx/sites-available/whatsapp << 'EOF'
server {
    listen 80;
    server_name meudominio.com;
    
    location / {
        proxy_pass http://localhost:3333;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
EOF

ln -s /etc/nginx/sites-available/whatsapp /etc/nginx/sites-enabled/
nginx -t
systemctl restart nginx
```

## SSL (HTTPS) - Opcional

```bash
apt install certbot python3-certbot-nginx -y
certbot --nginx -d meudominio.com
```

## Comandos Úteis

```bash
# Ver status
docker-compose ps

# Ver logs
docker-compose logs -f

# Reiniciar
docker-compose restart

# Parar
docker-compose down

# Atualizar código
docker-compose pull
docker-compose up -d
```

## Portas Necessárias

- `3333` - Interface Web do Rotator
- `8080` - Evolution API
- `22` - SSH (já deve estar aberto)

Configure no firewall da Hostinger:
- Acesse o painel Hostinger → VPS → Firewall
- Libere as portas 3333 e 8080

## Primeiro Uso

1. Acesse `http://IP_DA_VPS:3333`
2. Clique em "Nova Instância"
3. Digite um nome (ex: "instancia1")
4. Clique "Conectar" para ver o QR Code
5. Escaneie com o WhatsApp do celular
6. Faça upload do CSV (telefone,nome)
7. Escreva a mensagem e clique "Iniciar Disparo"

## Suporte

Problemas? Verifique os logs:
```bash
docker-compose logs evolution-api
docker-compose logs rotator
```
