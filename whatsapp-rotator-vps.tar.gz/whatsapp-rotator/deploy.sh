#!/bin/bash
# Deploy completo do WhatsApp Rotator

echo "🚀 WhatsApp Rotator - Deploy"
echo "============================"
echo ""

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Check Docker
if ! command -v docker &> /dev/null; then
    echo "❌ Docker não encontrado"
    exit 1
fi

# Create .env if not exists
if [ ! -f ".env" ]; then
    echo -e "${YELLOW}Criando .env...${NC}"
    
    API_KEY=$(openssl rand -base64 32 2>/dev/null || date +%s | sha256sum | head -c 32)
    
    cat > .env << EOF
# WhatsApp Rotator Configuration
EVOLUTION_API_URL=http://evolution-api:8080
EVOLUTION_API_KEY=${API_KEY}

# Rotação
ROTATION_MODE=round-robin
MESSAGES_PER_INSTANCE=100
COOLDOWN_BETWEEN_INSTANCES=5

# Anti-Block
DELAY_MIN_MS=5000
DELAY_MAX_MS=10000
DAILY_LIMIT_PER_INSTANCE=200
EOF
    
    echo -e "${GREEN}✓ .env criado${NC}"
    echo -e "${YELLOW}⚠️  API Key gerada: ${API_KEY}${NC}"
else
    echo -e "${GREEN}✓ .env já existe${NC}"
fi

# Create directories
mkdir -p data instances mailing

# Build and start
echo ""
echo "🔨 Buildando containers..."
docker-compose build

echo ""
echo "🚀 Iniciando serviços..."
docker-compose up -d

echo ""
echo "⏳ Aguardando Evolution API iniciar..."
sleep 15

echo ""
echo "============================"
echo -e "${GREEN}✅ Deploy concluído!${NC}"
echo ""
echo -e "${BLUE}Serviços:${NC}"
echo "  📱 Evolution API: http://localhost:8080"
echo "  📊 Manager: http://localhost:8080/manager"
echo ""
echo -e "${BLUE}Para usar o Rotator:${NC}"
echo "  docker-compose exec rotator node src/cli.js"
echo ""
echo -e "${BLUE}Ou execute interativo:${NC}"
echo "  docker-compose exec rotator sh"
echo "  node src/cli.js"
echo ""
echo "Próximos passos:"
echo "  1. Acesse http://localhost:8080/manager"
echo "  2. Crie uma instância manualmente para testar"
echo "  3. Use o CLI para criar e gerenciar instâncias"
echo ""
