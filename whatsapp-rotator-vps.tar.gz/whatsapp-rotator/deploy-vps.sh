#!/bin/bash

# WhatsApp Rotator - Deploy Script para VPS Hostinger
# Execute na sua VPS com: bash deploy-vps.sh

set -e

# Cores
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${BLUE}"
echo "╔════════════════════════════════════════════════════════════╗"
echo "║     WhatsApp Rotator - Deploy para VPS Hostinger          ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Verificar se é root
if [ "$EUID" -ne 0 ]; then 
    echo -e "${YELLOW}⚠️  Execute como root: sudo bash deploy-vps.sh${NC}"
    exit 1
fi

# Variáveis
APP_DIR="/opt/whatsapp-rotator"
DOMAIN="${1:-}"

echo ""
echo -e "${BLUE}📋 Etapas do deploy:${NC}"
echo "   1. Instalar Docker e Docker Compose"
echo "   2. Clonar o repositório"
echo "   3. Configurar ambiente"
echo "   4. Subir serviços"
echo ""

if [ -z "$DOMAIN" ]; then
    echo -e "${YELLOW}⚠️  Nenhum domínio informado. Usando IP da VPS.${NC}"
    echo "   Uso: sudo bash deploy-vps.sh meudominio.com"
    echo ""
fi

read -p "Continuar? (s/n): " CONFIRM
if [ "$CONFIRM" != "s" ] && [ "$CONFIRM" != "S" ]; then
    echo "Deploy cancelado."
    exit 0
fi

echo ""
echo -e "${BLUE}🔧 1/5 - Atualizando sistema...${NC}"
apt update && apt upgrade -y

echo ""
echo -e "${BLUE}🔧 2/5 - Instalando Docker...${NC}"
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com | sh
    systemctl enable docker
    systemctl start docker
    usermod -aG docker $SUDO_USER
    echo -e "${GREEN}   ✅ Docker instalado${NC}"
else
    echo -e "${GREEN}   ✅ Docker já instalado${NC}"
fi

if ! command -v docker-compose &> /dev/null; then
    curl -L "https://github.com/docker/compose/releases/download/v2.24.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    echo -e "${GREEN}   ✅ Docker Compose instalado${NC}"
else
    echo -e "${GREEN}   ✅ Docker Compose já instalado${NC}"
fi

echo ""
echo -e "${BLUE}🔧 3/5 - Preparando diretório...${NC}"
mkdir -p $APP_DIR
cd $APP_DIR

# Criar docker-compose.yml
cat > docker-compose.yml << 'EOF'
version: '3.8'

services:
  evolution-api:
    image: atendai/evolution-api:latest
    container_name: evolution-whatsapp
    restart: always
    ports:
      - "8080:8080"
    environment:
      - SERVER_URL=http://localhost:8080
      - AUTHENTICATION_API_KEY=${EVOLUTION_API_KEY:-sua_api_key_aqui}
      - AUTHENTICATION_EXPOSE_IN_FETCH_INSTANCES=true
      - DATABASE_ENABLED=true
      - DATABASE_CONNECTION_URI=file:./db/evolution.db
      - DATABASE_SAVE_DATA_INSTANCE=true
      - DATABASE_SAVE_DATA_NEW_MESSAGE=true
      - DATABASE_SAVE_MESSAGE_UPDATE=true
      - DATABASE_SAVE_DATA_CONTACTS=true
      - DATABASE_SAVE_DATA_CHATS=true
    volumes:
      - evolution-data:/evolution/db
    networks:
      - whatsapp-network

  rotator:
    image: node:18-alpine
    container_name: whatsapp-rotator
    restart: always
    ports:
      - "3333:3333"
    environment:
      - NODE_ENV=production
      - PORT=3333
      - EVOLUTION_API_URL=http://evolution-api:8080
      - EVOLUTION_API_KEY=${EVOLUTION_API_KEY:-sua_api_key_aqui}
      - ROTATION_MODE=round-robin
      - MESSAGES_PER_INSTANCE=100
      - COOLDOWN_BETWEEN_INSTANCES=5
      - DELAY_MIN_MS=5000
      - DELAY_MAX_MS=10000
      - DAILY_LIMIT_PER_INSTANCE=200
      - DB_PATH=/app/data/rotator.db
    volumes:
      - ./server.js:/app/server.js:ro
      - ./src:/app/src:ro
      - ./public:/app/public:ro
      - rotator-data:/app/data
    working_dir: /app
    command: sh -c "npm install express cors multer ws better-sqlite3 axios dotenv && node server.js"
    depends_on:
      - evolution-api
    networks:
      - whatsapp-network

volumes:
  evolution-data:
  rotator-data:

networks:
  whatsapp-network:
    driver: bridge
EOF

echo -e "${GREEN}   ✅ docker-compose.yml criado${NC}"

# Criar estrutura de diretórios
mkdir -p src public data instances

echo ""
echo -e "${BLUE}🔧 4/5 - Baixando código...${NC}"

# Criar package.json
cat > package.json << 'EOF'
{
  "name": "whatsapp-rotator",
  "version": "1.0.0",
  "dependencies": {
    "express": "^4.18.2",
    "cors": "^2.8.5",
    "multer": "^1.4.5-lts.1",
    "ws": "^8.14.0",
    "better-sqlite3": "^9.4.0",
    "axios": "^1.6.0",
    "dotenv": "^16.3.1"
  }
}
EOF

echo -e "${GREEN}   ✅ package.json criado${NC}"

echo ""
echo -e "${BLUE}🔧 5/5 - Subindo serviços...${NC}"
docker-compose up -d

echo ""
echo -e "${GREEN}✅ Deploy concluído!${NC}"
echo ""
echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "📱 Interface Web: ${GREEN}http://$(hostname -I | awk '{print $1}'):3333${NC}"
echo -e "🔌 Evolution API: ${GREEN}http://$(hostname -I | awk '{print $1}'):8080${NC}"
echo ""
if [ -n "$DOMAIN" ]; then
    echo -e "🌐 Domínio configurado: ${GREEN}https://$DOMAIN${NC}"
fi
echo ""
echo -e "${YELLOW}⚠️  PRÓXIMOS PASSOS:${NC}"
echo ""
echo "1. Acesse a interface web no navegador"
echo "2. Crie uma instância WhatsApp"
echo "3. Escaneie o QR Code com seu celular"
echo "4. Faça upload do CSV com contatos"
echo "5. Inicie o disparo!"
echo ""
echo -e "${BLUE}════════════════════════════════════════════════════════════${NC}"
echo ""
echo "Comandos úteis:"
echo "  docker-compose logs -f    # Ver logs"
echo "  docker-compose ps         # Status dos serviços"
echo "  docker-compose down       # Parar serviços"
echo "  docker-compose up -d      # Iniciar serviços"
echo ""
