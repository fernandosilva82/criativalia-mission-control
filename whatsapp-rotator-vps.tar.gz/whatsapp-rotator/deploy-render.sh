#!/bin/bash

# WhatsApp Rotator - Deploy Script for Render
set -e

echo "🚀 WhatsApp Rotator - Deploy para Render"
echo "=========================================="

# Cores
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Verificar se está no diretório correto
if [ ! -f "render.yaml" ]; then
    echo "❌ Erro: render.yaml não encontrado. Execute do diretório do projeto."
    exit 1
fi

echo ""
echo "📋 O que será feito:"
echo "   1. Criar serviço Evolution API no Render"
echo "   2. Criar serviço WhatsApp Rotator no Render"
echo "   3. Configurar persistência de dados"
echo ""

echo "🔧 Preparando arquivos..."

# Criar .gitignore se não existir
if [ ! -f ".gitignore" ]; then
    cat > .gitignore << 'EOF'
node_modules/
data/
instances/
*.db
.env
.DS_Store
EOF
    echo "   ✓ .gitignore criado"
fi

# Criar diretórios necessários
mkdir -p data instances public src

echo ""
echo "📦 Estrutura do projeto:"
find . -maxdepth 2 -type f -name "*.js" -o -name "*.json" -o -name "*.yml" -o -name "Dockerfile" -o -name "*.html" | head -20

echo ""
echo "📤 Próximos passos:"
echo ""
echo "${BLUE}Opção 1 - Deploy via GitHub (Recomendado):${NC}"
echo "   1. Crie um repositório no GitHub:"
echo "      github.com/new"
echo ""
echo "   2. Envie o código:"
echo "      git init"
echo "      git add ."
echo "      git commit -m 'Initial commit'"
echo "      git branch -M main"
echo "      git remote add origin https://github.com/SEU_USUARIO/whatsapp-rotator.git"
echo "      git push -u origin main"
echo ""
echo "   3. No Render, clique em 'New +' → 'Blueprint'"
echo "      Cole a URL do seu repo: https://github.com/SEU_USUARIO/whatsapp-rotator"
echo ""
echo "   4. O Render vai criar automaticamente:"
echo "      - evolution-whatsapp (API Evolution)"
echo "      - whatsapp-rotator (Interface Web)"
echo ""
echo "${BLUE}Opção 2 - Deploy Manual:${NC}"
echo "   1. Acesse: dashboard.render.com"
echo "   2. New + → Web Service"
echo "   3. Conecte seu GitHub e selecione o repo"
echo "   4. Configure:"
echo "      - Name: whatsapp-rotator"
echo "      - Runtime: Docker"
echo "      - Plan: Standard ($7/mês)"
echo ""
echo "${GREEN}⚠️ IMPORTANTE:${NC}"
echo "   - O plano Free do Render não suporta WebSocket persistente"
echo "   - Recomendado: Plan Standard ($7/mês) para cada serviço"
echo "   - Ou use o plano Starter ($0.10/hora quando ativo)"
echo ""
echo "${GREEN}🔐 Configurações pós-deploy:${NC}"
echo "   1. Anote a URL da Evolution API (ex: https://evolution-whatsapp.onrender.com)"
echo "   2. Anote a API Key gerada no painel do Render"
echo "   3. Configure estas variáveis no serviço 'whatsapp-rotator':"
echo "      EVOLUTION_API_URL=https://evolution-whatsapp.onrender.com"
echo "      EVOLUTION_API_KEY=<sua_api_key>"
echo ""
echo "🎉 Depois do deploy, acesse:"
echo "   Interface Web: https://whatsapp-rotator.onrender.com"
echo "   Evolution API: https://evolution-whatsapp.onrender.com"
echo ""
