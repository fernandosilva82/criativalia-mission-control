const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 7778;

app.use(cors());
app.use(express.json({ limit: '10mb' }));

// Database
const DB_PATH = '/opt/agency/database/agency.db';
const db = new sqlite3.Database(DB_PATH);

// Init database
function initDB() {
  db.serialize(() => {
    // Tabela de campanhas
    db.run(`CREATE TABLE IF NOT EXISTS campaigns (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      status TEXT DEFAULT 'draft',
      template_id INTEGER,
      mailing_id INTEGER,
      total_recipients INTEGER DEFAULT 0,
      sent_count INTEGER DEFAULT 0,
      delivered_count INTEGER DEFAULT 0,
      read_count INTEGER DEFAULT 0,
      replied_count INTEGER DEFAULT 0,
      failed_count INTEGER DEFAULT 0,
      conversion_rate REAL DEFAULT 0,
      scheduled_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Tabela de templates
    db.run(`CREATE TABLE IF NOT EXISTS templates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      content TEXT NOT NULL,
      variables TEXT,
      category TEXT DEFAULT 'general',
      is_active BOOLEAN DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Tabela de mailing
    db.run(`CREATE TABLE IF NOT EXISTS mailing_lists (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      description TEXT,
      total_contacts INTEGER DEFAULT 0,
      valid_contacts INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Tabela de contatos
    db.run(`CREATE TABLE IF NOT EXISTS contacts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      mailing_id INTEGER,
      phone TEXT NOT NULL,
      name TEXT,
      email TEXT,
      custom_data TEXT,
      status TEXT DEFAULT 'pending',
      verified_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Tabela de logs de envio
    db.run(`CREATE TABLE IF NOT EXISTS send_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      campaign_id INTEGER,
      contact_id INTEGER,
      instance_id INTEGER,
      status TEXT,
      delivered BOOLEAN DEFAULT 0,
      read BOOLEAN DEFAULT 0,
      replied BOOLEAN DEFAULT 0,
      error_message TEXT,
      sent_at DATETIME,
      delivered_at DATETIME,
      read_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);

    // Tabela de métricas diárias
    db.run(`CREATE TABLE IF NOT EXISTS daily_metrics (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT UNIQUE,
      sent INTEGER DEFAULT 0,
      delivered INTEGER DEFAULT 0,
      read INTEGER DEFAULT 0,
      replied INTEGER DEFAULT 0,
      failed INTEGER DEFAULT 0,
      conversion_rate REAL DEFAULT 0
    )`);

    console.log('Database initialized');
  });
}

// Routes

// Dashboard stats com métricas de conversão
app.get('/api/stats', (req, res) => {
  const stats = {};
  
  db.get("SELECT COUNT(*) as total FROM campaigns", (err, row) => {
    stats.totalCampaigns = row?.total || 0;
    
    db.get("SELECT COUNT(*) as total FROM contacts WHERE status = 'valid'", (err, row) => {
      stats.totalContacts = row?.total || 0;
      
      // Métricas de hoje
      const today = new Date().toISOString().split('T')[0];
      db.get(
        "SELECT * FROM daily_metrics WHERE date = ?",
        [today],
        (err, row) => {
          stats.today = row || { sent: 0, delivered: 0, read: 0, replied: 0, failed: 0, conversion_rate: 0 };
          
          // Taxas de conversão geral
          db.get(`
            SELECT 
              SUM(sent_count) as total_sent,
              SUM(delivered_count) as total_delivered,
              SUM(read_count) as total_read,
              SUM(replied_count) as total_replied
            FROM campaigns
            WHERE status = 'completed'
          `, (err, row) => {
            const totals = row || {};
            stats.conversionRates = {
              delivery: totals.total_sent ? ((totals.total_delivered / totals.total_sent) * 100).toFixed(1) : 0,
              read: totals.total_delivered ? ((totals.total_read / totals.total_delivered) * 100).toFixed(1) : 0,
              reply: totals.total_read ? ((totals.total_replied / totals.total_read) * 100).toFixed(1) : 0
            };
            
            res.json(stats);
          });
        }
      );
    });
  });
});

// Métricas detalhadas por campanha
app.get('/api/campaigns/:id/metrics', (req, res) => {
  const campaignId = req.params.id;
  
  db.get(`
    SELECT 
      c.*,
      t.name as template_name,
      m.name as mailing_name,
      CASE 
        WHEN c.sent_count > 0 THEN ROUND((c.delivered_count * 100.0 / c.sent_count), 1)
        ELSE 0
      END as delivery_rate,
      CASE 
        WHEN c.delivered_count > 0 THEN ROUND((c.read_count * 100.0 / c.delivered_count), 1)
        ELSE 0
      END as read_rate,
      CASE 
        WHEN c.read_count > 0 THEN ROUND((c.replied_count * 100.0 / c.read_count), 1)
        ELSE 0
      END as reply_rate,
      CASE 
        WHEN c.sent_count > 0 THEN ROUND((c.replied_count * 100.0 / c.sent_count), 1)
        ELSE 0
      END as conversion_rate
    FROM campaigns c
    LEFT JOIN templates t ON c.template_id = t.id
    LEFT JOIN mailing_lists m ON c.mailing_id = m.id
    WHERE c.id = ?
  `, [campaignId], (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    if (!row) return res.status(404).json({ error: 'Campaign not found' });
    res.json(row);
  });
});

// Templates
app.get('/api/templates', (req, res) => {
  db.all("SELECT * FROM templates WHERE is_active = 1 ORDER BY created_at DESC", (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/templates', (req, res) => {
  const { name, content, variables, category } = req.body;
  
  db.run(
    "INSERT INTO templates (name, content, variables, category) VALUES (?, ?, ?, ?)",
    [name, content, JSON.stringify(variables || []), category || 'general'],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID, message: 'Template created' });
    }
  );
});

// Preview de template
app.post('/api/templates/preview', (req, res) => {
  const { template_id, sample_data } = req.body;
  
  db.get("SELECT * FROM templates WHERE id = ?", [template_id], (err, template) => {
    if (err || !template) {
      return res.status(404).json({ error: 'Template not found' });
    }
    
    let content = template.content;
    const variables = JSON.parse(template.variables || '[]');
    
    variables.forEach(variable => {
      const value = sample_data[variable] || `{{${variable}}}`;
      content = content.replace(new RegExp(`{{${variable}}}`, 'g'), value);
    });
    
    res.json({ preview: content });
  });
});

// Campaigns
app.get('/api/campaigns', (req, res) => {
  db.all(`
    SELECT 
      c.*, 
      t.name as template_name, 
      m.name as mailing_name,
      CASE 
        WHEN c.total_recipients > 0 THEN ROUND((c.sent_count * 100.0 / c.total_recipients), 0)
        ELSE 0
      END as progress
    FROM campaigns c
    LEFT JOIN templates t ON c.template_id = t.id
    LEFT JOIN mailing_lists m ON c.mailing_id = m.id
    ORDER BY c.created_at DESC
  `, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.post('/api/campaigns', (req, res) => {
  const { name, template_id, mailing_id, scheduled_at } = req.body;
  
  db.run(
    "INSERT INTO campaigns (name, template_id, mailing_id, scheduled_at) VALUES (?, ?, ?, ?)",
    [name, template_id, mailing_id, scheduled_at || null],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID, message: 'Campaign created' });
    }
  );
});

// Mailing
app.get('/api/mailing', (req, res) => {
  db.all(`
    SELECT 
      ml.*,
      (SELECT COUNT(*) FROM contacts WHERE mailing_id = ml.id AND status = 'valid') as valid_count
    FROM mailing_lists ml
    ORDER BY ml.created_at DESC
  `, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// Verificador de números
app.post('/api/verifier/check', (req, res) => {
  const { mailing_id } = req.body;
  
  db.all(
    "SELECT * FROM contacts WHERE mailing_id = ? AND status = 'pending' LIMIT 100",
    [mailing_id],
    (err, contacts) => {
      if (err) return res.status(500).json({ error: err.message });
      
      // Simula verificação
      const results = contacts.map(c => ({
        ...c,
        status: Math.random() > 0.3 ? 'valid' : 'invalid'
      }));
      
      results.forEach(result => {
        db.run(
          "UPDATE contacts SET status = ?, verified_at = datetime('now') WHERE id = ?",
          [result.status, result.id]
        );
      });
      
      // Atualizar contagem na mailing list
      db.run(`
        UPDATE mailing_lists 
        SET valid_contacts = (SELECT COUNT(*) FROM contacts WHERE mailing_id = ? AND status = 'valid')
        WHERE id = ?
      `, [mailing_id, mailing_id]);
      
      res.json({
        checked: results.length,
        valid: results.filter(r => r.status === 'valid').length,
        invalid: results.filter(r => r.status === 'invalid').length
      });
    }
  );
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'agency-marketing-api' });
});

// Home
app.get('/', (req, res) => {
  res.json({ 
    status: 'ok', 
    service: 'Agency Marketing API',
    version: '1.0.0',
    features: [
      'Campaign management',
      'Template editor with variables',
      'Mailing list management',
      'WhatsApp number verification',
      'Conversion metrics',
      'Delivery tracking'
    ]
  });
});

// Start server
initDB();

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Agency Marketing API running on port ${PORT}`);
});
